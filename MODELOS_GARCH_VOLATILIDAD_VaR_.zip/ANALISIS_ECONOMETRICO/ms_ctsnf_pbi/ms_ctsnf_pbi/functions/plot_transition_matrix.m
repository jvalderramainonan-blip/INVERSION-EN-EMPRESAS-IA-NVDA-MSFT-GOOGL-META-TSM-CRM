function fig = plot_transition_matrix(ms_result)
% PLOT_TRANSITION_MATRIX  Heatmap de la matriz de transicion (archivo separado)

fig = figure('Units','centimeters','Position',[2 2 14 12],'Color','w');

P = ms_result.P_trans;
K = size(P,1);
labels_ax = {'Recesion','Expansion','Auge'};

imagesc(P);
colormap(flipud(hot));
caxis([0 1]);
colorbar;

for i = 1:K
    for j = 1:K
        if P(i,j) > 0.5
            tc = 'w';
        else
            tc = 'k';
        end
        text(j, i, sprintf('%.3f', P(i,j)), ...
             'HorizontalAlignment','center','FontSize',11, ...
             'FontWeight','bold','Color',tc);
    end
end

set(gca,'XTick',1:K,'YTick',1:K, ...
        'XTickLabel',labels_ax,'YTickLabel',labels_ax,'FontSize',9);
xlabel('Estado en t','FontSize',10);
ylabel('Estado en t-1','FontSize',10);
title('Matriz de Transicion Estimada P_{ij}','FontSize',10);
set(fig,'PaperPositionMode','auto');
end
