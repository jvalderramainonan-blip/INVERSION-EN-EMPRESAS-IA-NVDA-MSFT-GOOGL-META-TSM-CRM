function fig = plot_smoothed_probs(dates, ms_result)
% PLOT_SMOOTHED_PROBS  Probabilidades suavizadas de los 3 regimenes (archivo separado)
% Delegado desde plot_gdp_and_cycle.m; definicion repetida para independencia de archivos.

fig = figure('Units','centimeters','Position',[2 2 22 16],'Color','w');

labels = {'Recesion','Expansion','Auge'};
colors = {[0.85 0.20 0.20],[0.25 0.55 0.85],[0.18 0.60 0.18]};
probs  = {ms_result.sp_rec, ms_result.sp_exp, ms_result.sp_auge};

for k = 1:3
    ax = subplot(3,1,k);
    area(dates, probs{k}, 'FaceColor', colors{k}, 'FaceAlpha', 0.65, ...
         'EdgeColor', colors{k}*0.75, 'LineWidth',0.8);
    hold on;
    plot(dates, 0.5*ones(size(dates)), 'k--','LineWidth',0.9);
    ylim([0 1]);
    ylabel(sprintf('P(%s)', labels{k}),'FontSize',9);
    title(sprintf('P(s_t = %s | \\Omega_T)', labels{k}),'FontSize',10);
    set(ax,'FontSize',8,'XGrid','on','YGrid','on','GridAlpha',0.3);
    datetick('x','yyyy','keeplimits');
    if k == 3, xlabel('Periodo','FontSize',9); end
end

sgtitle('Probabilidades Suavizadas — Modelo MS-MH(3)','FontSize',12,'FontWeight','bold');
set(fig,'PaperPositionMode','auto');
end
