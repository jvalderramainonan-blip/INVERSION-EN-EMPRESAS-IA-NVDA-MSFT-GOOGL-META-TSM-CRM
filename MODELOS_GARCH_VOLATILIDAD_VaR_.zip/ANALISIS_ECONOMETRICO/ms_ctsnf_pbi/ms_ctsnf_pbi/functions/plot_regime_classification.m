function fig = plot_regime_classification(dates, cycle, ms_result)
% PLOT_REGIME_CLASSIFICATION  Ciclo coloreado segun el regimen de maxima probabilidad

fig = figure('Units','centimeters','Position',[2 2 22 10],'Color','w');

colors_map = [0.85 0.20 0.20;
              0.25 0.55 0.85;
              0.18 0.60 0.18];

rc = ms_result.regime_class;
cy_range = range(cycle);

hold on;
for k = 1:3
    idx = find(rc == k);
    for ii = 1:length(idx)
        t = idx(ii);
        t_lo = max(1, t-1);
        t_hi = min(length(dates), t);
        fill([dates(t_lo) dates(t_hi) dates(t_hi) dates(t_lo)], ...
             [-0.15 -0.15 0.15 0.15]*cy_range, colors_map(k,:), ...
             'EdgeColor','none','FaceAlpha',0.35,'HandleVisibility','off');
    end
end

plot(dates, cycle, 'k-','LineWidth',1.4);
plot(dates([1 end]), [0 0], '-','Color',[0.5 0.5 0.5],'LineWidth',0.8);

etiq = {'Recesion','Expansion','Auge'};
leg_h = zeros(3,1);
for k = 1:3
    leg_h(k) = patch(NaN, NaN, colors_map(k,:),'FaceAlpha',0.5,'EdgeColor','none');
end
legend(leg_h, etiq,'Location','northwest','FontSize',9);

ylabel('Ciclo CF Asimetrico','FontSize',10);
xlabel('Periodo','FontSize',10);
title('Clasificacion discreta de regimenes (maxima probabilidad)','FontSize',11);
set(gca,'FontSize',9,'XGrid','on','YGrid','on','GridAlpha',0.3);
datetick('x','yyyy','keeplimits');
set(fig,'PaperPositionMode','auto');
end
