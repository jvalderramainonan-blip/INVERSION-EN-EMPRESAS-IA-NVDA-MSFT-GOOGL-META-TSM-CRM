function s = datenum2qstr(dn)
% DATENUM2QSTR  Convierte un datenum a cadena trimestral 'YYYY-QN'
%
% SINTAXIS:
%   s = datenum2qstr(dn)
%
% ENTRADA:
%   dn  — escalar datenum de MATLAB (numero de serie de fecha)
%
% SALIDA:
%   s   — cadena de caracteres en formato 'YYYY-QN'
%         Ejemplo: 2024-Q3
%
% NOTA: datestr(d,'yyyy-QN') no es un formato valido en MATLAB
%       (QN no es un token reconocido). Esta funcion resuelve ese
%       problema de forma compatible con R2019b-R2023b y Octave 7+.
%
% AUTOR: Joan Valderrama Inonan  |  UNAC - Macroeconometria
% VERSION: 1.0  |  JUNIO 2026

dv  = datevec(dn);          % [year month day hour min sec]
yr  = dv(1);
mo  = dv(2);
q   = ceil(mo / 3);         % mes -> trimestre (1..4)
s   = sprintf('%d-Q%d', yr, q);

end
