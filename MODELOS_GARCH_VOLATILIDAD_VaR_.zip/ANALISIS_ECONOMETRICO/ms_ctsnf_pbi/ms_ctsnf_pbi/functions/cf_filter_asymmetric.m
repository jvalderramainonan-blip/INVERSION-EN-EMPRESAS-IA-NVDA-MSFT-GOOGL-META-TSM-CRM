function cycle = cf_filter_asymmetric(y, pl, pu, drift)
% CF_FILTER_ASYMMETRIC  Filtro Christiano-Fitzgerald asimetrico de banda de paso
%
% Extrae el componente ciclico de una serie de tiempo usando el filtro
% Christiano-Fitzgerald (2003). La version "asimetrica" usa todos los datos
% disponibles en cada extremo (no requiere observaciones simetricas), por lo
% que NO pierde puntos al inicio ni al final de la muestra.
%
% SINTAXIS:
%   cycle = cf_filter_asymmetric(y, pl, pu, drift)
%
% ENTRADAS:
%   y      - [Tx1] serie en logaritmos (o niveles)
%   pl     - periodo minimo del ciclo (ej: 6 para datos trimestrales)
%   pu     - periodo maximo del ciclo (ej: 32 para datos trimestrales)
%   drift  - true/false: incluir ajuste de extremos para I(1) con drift
%
% SALIDA:
%   cycle  - [Tx1] componente ciclico extraido
%
% REFERENCIAS:
%   Christiano & Fitzgerald (2003). The Band Pass Filter.
%   International Economic Review, 44(2), 435-465. Apendice B.
%
% CORRECCIONES v1.2 -> v1.3:
%   - Signo del ajuste de extremos corregido segun CF(2003) ec. (B.8):
%     los pesos a_{T-t} y b_{t-1} se RESTAN (no se suman) al valor filtrado,
%     ya que representan la energia que se "quita" de los extremos para que
%     el filtro anule el componente I(1).
%   - cf_tail_sum ahora devuelve la suma directa (positiva) de la cola;
%     el signo negativo se aplica en el cuerpo principal.

if nargin < 4, drift = true; end

y = y(:);   % forzar columna
T = length(y);

% Frecuencias de corte en radianes
wl = 2*pi / pu;   % frecuencia baja (ciclos largos)
wh = 2*pi / pl;   % frecuencia alta (ciclos cortos)

% --- Pesos ideales del filtro (Christiano & Fitzgerald, ec. 4) ---
% B_k = (sin(k*wh) - sin(k*wl)) / (pi*k)  para k ~= 0
% B_0 = (wh - wl) / pi

K_max = T - 1;
B = zeros(K_max + 1, 1);
B(1) = (wh - wl) / pi;   % k = 0 (indice MATLAB: 1)
for k = 1:K_max
    B(k+1) = (sin(k*wh) - sin(k*wl)) / (pi * k);
end

cycle = zeros(T, 1);

for t = 1:T
    % Indices disponibles hacia adelante y hacia atras
    k_ahead = T - t;    % observaciones disponibles despues de t
    k_back  = t - 1;    % observaciones disponibles antes de t

    % Valor filtrado (suma central)
    val = B(1) * y(t);
    for j = 1:k_ahead
        val = val + B(j+1) * y(t+j);
    end
    for j = 1:k_back
        val = val + B(j+1) * y(t-j);
    end

    if drift
        % Ajuste de extremos segun CF(2003) Apendice B, ec. (B.8):
        % Se RESTA la suma de la cola (con signo positivo de cf_tail_sum)
        % multiplicada por y(T) e y(1) respectivamente.
        % Esto garantiza que el filtro anule raices unitarias I(1) con drift.
        a_ahead = cf_tail_sum(k_ahead, B, wl, wh);
        a_back  = cf_tail_sum(k_back,  B, wl, wh);
        val = val - a_ahead * y(T) - a_back * y(1);
    end

    cycle(t) = val;
end

end

% -------------------------------------------------------------------------
% Funcion auxiliar: suma de la cola del filtro CF (aproximacion analitica)
% Devuelve la suma POSITIVA de sum_{j=k_max+1}^{inf} B_j
% El signo negativo se aplica en el cuerpo principal (correccion v1.3)
% -------------------------------------------------------------------------
function s = cf_tail_sum(k_max, B, wl, wh)

if k_max >= length(B) - 1
    s = 0;
    return;
end

% Suma directa de los pesos tabulados mas alla de k_max
available = B(k_max+2:end);
s_known = sum(available);

% Aproximacion de la cola no tabulada: integral numerica de alta orden
% Para j grande, B_j decae como 1/j -> la cola es pequenia
j_start = length(B);
j_end   = j_start + 5000;
j_range = j_start:j_end;
tail_approx = sum((sin(j_range*wh) - sin(j_range*wl)) ./ (pi * j_range));

s = s_known + tail_approx;   % suma positiva; el signo lo aplica el caller
end
