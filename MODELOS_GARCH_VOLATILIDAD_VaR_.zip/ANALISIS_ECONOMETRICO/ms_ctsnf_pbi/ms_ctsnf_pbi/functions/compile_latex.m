function status = compile_latex(tex_file)
% COMPILE_LATEX  Compila un archivo .tex a PDF usando pdflatex
%
% Ejecuta pdflatex dos veces para resolver referencias internas
% (tabla de contenidos, referencias cruzadas, bibliografia).
%
% SINTAXIS:
%   status = compile_latex(tex_file)
%
% ENTRADAS:
%   tex_file - ruta completa al archivo .tex
%
% SALIDA:
%   status - 0 si la compilacion fue exitosa, 1 en caso contrario
%
% REQUISITOS:
%   pdflatex debe estar disponible en el PATH del sistema.
%   Distribuciones recomendadas: TeX Live (Linux/Mac) o MiKTeX (Windows)

[tex_dir, tex_name, ~] = fileparts(tex_file);

% Verificar disponibilidad de pdflatex
[chk, ~] = system('pdflatex --version');
if chk ~= 0
    fprintf('      AVISO: pdflatex no encontrado en PATH.\n');
    fprintf('      Instale TeX Live o MiKTeX y vuelva a ejecutar compile_latex.\n');
    fprintf('      El archivo .tex esta disponible para compilacion manual en:\n');
    fprintf('        %s\n', tex_file);
    status = 1;
    return;
end

% Opciones de compilacion
opts = sprintf('-interaction=nonstopmode -output-directory "%s"', tex_dir);

% Primera pasada (genera .aux, .toc)
cmd1 = sprintf('pdflatex %s "%s"', opts, tex_file);
[s1, out1] = system(cmd1);

if s1 ~= 0
    fprintf('      ERROR en primera pasada de pdflatex.\n');
    fprintf('      Revise el log: %s\n', fullfile(tex_dir, [tex_name '.log']));
    if ~isempty(out1)
        lines = strsplit(out1, '\n');
        err_lines = lines(contains(lines, '!') | contains(lines, 'Error'));
        for i = 1:min(5, length(err_lines))
            fprintf('        %s\n', err_lines{i});
        end
    end
    status = 1;
    return;
end

% Segunda pasada (resuelve referencias)
[s2, ~] = system(cmd1);

if s2 ~= 0
    fprintf('      AVISO: Segunda pasada de pdflatex retorno error (puede ser menor).\n');
    status = 1;
else
    pdf_path = fullfile(tex_dir, [tex_name '.pdf']);
    if exist(pdf_path, 'file')
        fprintf('      PDF compilado exitosamente: %s\n', pdf_path);
        status = 0;
    else
        fprintf('      AVISO: pdflatex no genero el PDF esperado.\n');
        status = 1;
    end
end

% Limpiar archivos auxiliares
aux_exts = {'.aux', '.log', '.toc', '.out', '.bbl', '.blg'};
for i = 1:length(aux_exts)
    aux_file = fullfile(tex_dir, [tex_name aux_exts{i}]);
    if exist(aux_file, 'file')
        delete(aux_file);
    end
end

end
