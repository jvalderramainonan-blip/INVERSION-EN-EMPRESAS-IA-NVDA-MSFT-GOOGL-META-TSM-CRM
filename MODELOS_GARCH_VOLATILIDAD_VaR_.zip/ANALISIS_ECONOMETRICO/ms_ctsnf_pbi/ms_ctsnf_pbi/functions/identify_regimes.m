function result = identify_regimes(result)
% IDENTIFY_REGIMES  Asigna etiquetas economicas a los regimenes por media estimada
%
% Ordena los K regimenes segun su media estimada (mu) de menor a mayor:
%   - Estado con menor media  -> Recesion
%   - Estado intermedio       -> Expansion
%   - Estado con mayor media  -> Auge
%
% Esta convencion sigue a Hamilton (1989) y Kim & Nelson (1999), donde el
% ciclo negativo (brecha del producto < 0) corresponde a recesion.
%
% Para K=3 el ordenamiento es unico. Para K>3 se generaliza del mismo modo.
%
% ENTRADA/SALIDA: estructura result (se enriquece con campos de regimen)

K  = result.K;
mu = result.mu;

% Ordenar regimenes por media de menor a mayor
[mu_sorted, idx_order] = sort(mu);

% Reasignar probabilidades suavizadas con la nueva ordenacion
xi_smooth_sorted = result.xi_smooth(:, idx_order);
sigma_sorted     = result.sigma(idx_order);

% Campos genericos (regimen 1=menor media ... K=mayor media)
result.mu_sorted    = mu_sorted;
result.sigma_sorted = sigma_sorted;
result.xi_smooth    = xi_smooth_sorted;

% Reasignar matriz de transicion al nuevo orden
P_new = result.P_trans(idx_order, idx_order);
result.P_trans = P_new;

% Etiquetas especificas para K=3
if K == 3
    result.sp_rec  = xi_smooth_sorted(:, 1);
    result.sp_exp  = xi_smooth_sorted(:, 2);
    result.sp_auge = xi_smooth_sorted(:, 3);
    
    result.mu_rec   = mu_sorted(1);
    result.mu_exp   = mu_sorted(2);
    result.mu_auge  = mu_sorted(3);
    
    result.sigma_rec  = sigma_sorted(1);
    result.sigma_exp  = sigma_sorted(2);
    result.sigma_auge = sigma_sorted(3);
    
    % Estado de mayor probabilidad en cada periodo (clasificacion discreta)
    [~, regime_class] = max(xi_smooth_sorted, [], 2);
    result.regime_class = regime_class;   % 1=Rec, 2=Exp, 3=Auge
    
    % Periodos en cada regimen
    result.n_rec  = sum(regime_class == 1);
    result.n_exp  = sum(regime_class == 2);
    result.n_auge = sum(regime_class == 3);
    
    % Probabilidades de transicion con etiquetas
    result.p_rr = P_new(1,1);   % Rec -> Rec
    result.p_re = P_new(1,2);   % Rec -> Exp
    result.p_ra = P_new(1,3);   % Rec -> Auge
    result.p_er = P_new(2,1);   % Exp -> Rec
    result.p_ee = P_new(2,2);   % Exp -> Exp
    result.p_ea = P_new(2,3);   % Exp -> Auge
    result.p_ar = P_new(3,1);   % Auge -> Rec
    result.p_ae = P_new(3,2);   % Auge -> Exp
    result.p_aa = P_new(3,3);   % Auge -> Auge
    
    % Duraciones esperadas: E[d_k] = 1/(1 - p_kk)
    result.dur_rec  = 1 / (1 - result.p_rr + 1e-12);
    result.dur_exp  = 1 / (1 - result.p_ee + 1e-12);
    result.dur_auge = 1 / (1 - result.p_aa + 1e-12);
    
else
    % Caso general K != 3
    result.sp_all = xi_smooth_sorted;
    [~, result.regime_class] = max(xi_smooth_sorted, [], 2);
end

end
