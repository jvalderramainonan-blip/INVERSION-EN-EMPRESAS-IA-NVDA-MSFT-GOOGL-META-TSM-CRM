function res = run_ms_pipeline(cfg)
% RUN_MS_PIPELINE  Ejecuta un pipeline MS-MH(3) para una serie trimestral
%
% Version compatible con MATLAB R2019b: no usa bloque arguments.

% --------------------------
% Validacion y valores por defecto
% --------------------------
if ~isstruct(cfg)
    error('run_ms_pipeline:InvalidInput', 'cfg debe ser una estructura.');
end

required = {'series_name','series_tag','csv_path','loader_fun','plot_fun','output_dir'};
for i = 1:numel(required)
    if ~isfield(cfg, required{i}) || isempty(cfg.(required{i}))
        error('run_ms_pipeline:MissingField', 'Falta el campo requerido cfg.%s.', required{i});
    end
end

if ~isfield(cfg, 'cf_pl') || isempty(cfg.cf_pl), cfg.cf_pl = 6; end
if ~isfield(cfg, 'cf_pu') || isempty(cfg.cf_pu), cfg.cf_pu = 32; end
if ~isfield(cfg, 'cf_drift') || isempty(cfg.cf_drift), cfg.cf_drift = true; end
if ~isfield(cfg, 'states') || isempty(cfg.states), cfg.states = 3; end
if ~isfield(cfg, 'maxiter') || isempty(cfg.maxiter), cfg.maxiter = 2000; end
if ~isfield(cfg, 'tol') || isempty(cfg.tol), cfg.tol = 1e-8; end
if ~isfield(cfg, 'n_restarts') || isempty(cfg.n_restarts), cfg.n_restarts = 15; end
if ~isfield(cfg, 'quantile_lo') || isempty(cfg.quantile_lo), cfg.quantile_lo = 0.25; end
if ~isfield(cfg, 'quantile_hi') || isempty(cfg.quantile_hi), cfg.quantile_hi = 0.75; end
if ~isfield(cfg, 'seed') || isempty(cfg.seed), cfg.seed = 42; end
if ~isfield(cfg, 'use_growth_rate') || isempty(cfg.use_growth_rate), cfg.use_growth_rate = true; end

if ~isa(cfg.loader_fun, 'function_handle')
    error('run_ms_pipeline:InvalidLoader', 'cfg.loader_fun debe ser un function_handle.');
end
if ~isa(cfg.plot_fun, 'function_handle')
    error('run_ms_pipeline:InvalidPlotter', 'cfg.plot_fun debe ser un function_handle.');
end

if ~exist(cfg.output_dir, 'dir')
    mkdir(cfg.output_dir);
end

rng(cfg.seed);

fprintf('\n=============================================================\n');
fprintf('  PROCESANDO: %s\n', cfg.series_name);
fprintf('=============================================================\n');

% -------------------------------------------------------------------------
% 1. Carga de datos
% -------------------------------------------------------------------------
[dates_raw, series_log] = cfg.loader_fun(cfg.csv_path);

fprintf('      Observaciones (niveles): %d\n', length(series_log));
fprintf('      Periodo (niveles): %s  a  %s\n', datenum2qstr(dates_raw(1)), ...
        datenum2qstr(dates_raw(end)));

% -------------------------------------------------------------------------
% 2. Transformacion a tasa de crecimiento
% -------------------------------------------------------------------------
if cfg.use_growth_rate
    series_growth = 100 * diff(series_log);
    dates         = dates_raw(2:end);
    series_for_cf = series_growth;
    fprintf('      Observaciones (crecimientos): %d\n', length(series_growth));
    fprintf('      Media=%.4f%%  SD=%.4f%%\n', mean(series_growth), std(series_growth));
else
    series_growth = series_log;
    dates         = dates_raw;
    series_for_cf = series_log;
end

% -------------------------------------------------------------------------
% 3. Filtro CF asimetrico
% -------------------------------------------------------------------------
cycle_raw = cf_filter_asymmetric(series_for_cf, cfg.cf_pl, cfg.cf_pu, cfg.cf_drift);

cycle_mean_raw = mean(cycle_raw);
cycle_sd_raw   = std(cycle_raw);

if cycle_sd_raw <= 0 || isnan(cycle_sd_raw)
    error('run_ms_pipeline:InvalidCycle', 'La desviacion estandar del ciclo es invalida.');
end

cycle_z  = (cycle_raw - cycle_mean_raw) / cycle_sd_raw;
umbral_rec  = quantile(cycle_raw, cfg.quantile_lo);
umbral_auge = quantile(cycle_raw, cfg.quantile_hi);
cy_last_raw = cycle_raw(end);

fprintf('      Ciclo (sin estandarizar): media=%.4f  sd=%.4f  min=%.4f  max=%.4f\n', ...
        mean(cycle_raw), std(cycle_raw), min(cycle_raw), max(cycle_raw));
fprintf('      Umbral recesion (p%.0f): %.4f\n', 100*cfg.quantile_lo, umbral_rec);
fprintf('      Umbral auge     (p%.0f): %.4f\n', 100*cfg.quantile_hi, umbral_auge);
fprintf('      Ultimo valor del ciclo:  %.4f\n', cy_last_raw);

% -------------------------------------------------------------------------
% 4. Estimacion Markov Switching
% -------------------------------------------------------------------------
params = struct();
params.states     = cfg.states;
params.maxiter    = cfg.maxiter;
params.tol        = cfg.tol;
params.n_restarts = cfg.n_restarts;
params.seed       = cfg.seed;

ms_result = estimate_markov_switching(cycle_z, params);
ms_result = identify_regimes(ms_result);

% Reconversion a unidades originales del ciclo
mu_rec_orig   = ms_result.mu_rec   * cycle_sd_raw + cycle_mean_raw;
mu_exp_orig   = ms_result.mu_exp   * cycle_sd_raw + cycle_mean_raw;
mu_auge_orig  = ms_result.mu_auge  * cycle_sd_raw + cycle_mean_raw;
sig_rec_orig  = ms_result.sigma_rec  * cycle_sd_raw;
sig_exp_orig  = ms_result.sigma_exp  * cycle_sd_raw;
sig_auge_orig = ms_result.sigma_auge * cycle_sd_raw;

fprintf('      Regimen 1 (Recesion):  mu=%.4f  sigma=%.4f\n', mu_rec_orig,  sig_rec_orig);
fprintf('      Regimen 2 (Expansion): mu=%.4f  sigma=%.4f\n', mu_exp_orig,  sig_exp_orig);
fprintf('      Regimen 3 (Auge):      mu=%.4f  sigma=%.4f\n', mu_auge_orig, sig_auge_orig);

% -------------------------------------------------------------------------
% 5. Figuras
% -------------------------------------------------------------------------
fig1 = cfg.plot_fun(dates, series_log, cycle_raw, ms_result);
saveas(fig1, fullfile(cfg.output_dir, 'fig1_series.pdf'));

fig2 = plot_smoothed_probs(dates, ms_result);
saveas(fig2, fullfile(cfg.output_dir, 'fig2_smoothed_probs.pdf'));

fig3 = plot_transition_matrix(ms_result);
saveas(fig3, fullfile(cfg.output_dir, 'fig3_transition_matrix.pdf'));

fig4 = plot_regime_classification(dates, cycle_raw, ms_result);
saveas(fig4, fullfile(cfg.output_dir, 'fig4_regime_classification.pdf'));

fprintf('      Figuras guardadas en: %s/\n', cfg.output_dir);

% -------------------------------------------------------------------------
% 6. Empaquetar resultados
% -------------------------------------------------------------------------
pms_rec  = ms_result.sp_rec(end);
pms_exp  = ms_result.sp_exp(end);
pms_auge = ms_result.sp_auge(end);

res = struct();
res.series_name    = cfg.series_name;
res.series_tag     = cfg.series_tag;
res.csv_path       = cfg.csv_path;
res.output_dir     = cfg.output_dir;
res.first_date     = dates(1);
res.last_date      = dates(end);
res.first_date_str = datenum2qstr(dates(1));
res.last_date_str  = datenum2qstr(dates(end));
res.dates          = dates;
res.series_log     = series_log;
res.series_growth  = series_growth;
res.cycle_raw      = cycle_raw;
res.cycle_mean_raw = cycle_mean_raw;
res.cycle_sd_raw   = cycle_sd_raw;
res.cycle_z        = cycle_z;
res.cy_nobs        = sum(~isnan(cycle_raw));
res.cy_last        = cy_last_raw;
res.umbral_rec     = umbral_rec;
res.umbral_auge    = umbral_auge;
res.cy_mean        = cycle_mean_raw;
res.cy_sd          = cycle_sd_raw;
res.ms             = ms_result;
res.mu_rec_orig    = mu_rec_orig;
res.mu_exp_orig    = mu_exp_orig;
res.mu_auge_orig   = mu_auge_orig;
res.sig_rec_orig   = sig_rec_orig;
res.sig_exp_orig   = sig_exp_orig;
res.sig_auge_orig  = sig_auge_orig;
res.params         = params;
res.pms_rec        = pms_rec;
res.pms_exp        = pms_exp;
res.pms_auge       = pms_auge;

[~, reg_dom] = max([pms_rec, pms_exp, pms_auge]);
res.dom_regime_idx = reg_dom;
res.dom_regime_prob = max([pms_rec, pms_exp, pms_auge]);

fprintf('\n=============================================================\n');
fprintf('  RESUMEN: %s\n', cfg.series_name);
fprintf('  Periodo: %s  a  %s\n', res.first_date_str, res.last_date_str);
fprintf('  Ciclo ultimo periodo: %.4f\n', res.cy_last);
fprintf('  P(Recesion)  = %.2f%%\n', 100*pms_rec);
fprintf('  P(Expansion) = %.2f%%\n', 100*pms_exp);
fprintf('  P(Auge)      = %.2f%%\n', 100*pms_auge);
fprintf('=============================================================\n');

end
