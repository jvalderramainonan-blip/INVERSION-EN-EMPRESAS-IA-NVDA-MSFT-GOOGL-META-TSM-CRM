function [dates, gdp_log] = load_gdp_csv(csv_path)
% LOAD_GDP_CSV  Carga datos de PIB real desde CSV
%
% FORMATO ESPERADO DEL CSV:
%   - Columna 1: fecha en formato YYYY-QN (ej: 1947-Q1) o YYYY-MM-DD
%   - Columna 2: PIB real (nivel, no logaritmo)
%   - Primera fila: encabezado (se omite)
%
% CORRECCIONES v1.2 -> v1.3:
%   - Eliminada la subfuncion interna generate_synthetic_gdp, que era
%     codigo muerto (nunca se alcanzaba desde esta funcion) y dificultaba
%     la lectura. La funcion generate_synthetic_gdp vive unicamente en
%     su propio archivo .m.

opts = detectImportOptions(csv_path);
opts.VariableNamesLine = 1;
T_data = readtable(csv_path, opts);

% Detectar columna de fecha y PIB
col_fecha = T_data{:,1};
col_gdp   = T_data{:,2};

% Convertir fechas
dates = parse_dates(col_fecha);

% Logaritmo natural del PIB
if any(col_gdp <= 0)
    error('LOAD_GDP_CSV: El PIB contiene valores no positivos. Verifique los datos.');
end
gdp_log = log(col_gdp);

% Ordenar cronologicamente
[dates, ord] = sort(dates);
gdp_log = gdp_log(ord);

% Remover NaN
valid   = ~isnan(gdp_log) & ~isnan(dates);
dates   = dates(valid);
gdp_log = gdp_log(valid);

end

% -------------------------------------------------------------------------

function dates_num = parse_dates(raw)
% Intenta parsear fechas en formato YYYY-QN, YYYY-QQ o YYYY-MM-DD

n = length(raw);
dates_num = NaN(n,1);

for i = 1:n
    s = strtrim(char(raw{i}));

    % Formato YYYY-QN (trimestral)
    tok = regexp(s, '^(\d{4})-Q(\d)$', 'tokens');
    if ~isempty(tok)
        yr  = str2double(tok{1}{1});
        qtr = str2double(tok{1}{2});
        mo  = (qtr-1)*3 + 1;
        dates_num(i) = datenum(yr, mo, 1);
        continue;
    end

    % Formato YYYY-MM-DD
    try
        dates_num(i) = datenum(s, 'yyyy-mm-dd');
        continue;
    catch
    end

    % Formato YYYYMMDD
    try
        dates_num(i) = datenum(s, 'yyyymmdd');
    catch
        dates_num(i) = NaN;
    end
end

end
