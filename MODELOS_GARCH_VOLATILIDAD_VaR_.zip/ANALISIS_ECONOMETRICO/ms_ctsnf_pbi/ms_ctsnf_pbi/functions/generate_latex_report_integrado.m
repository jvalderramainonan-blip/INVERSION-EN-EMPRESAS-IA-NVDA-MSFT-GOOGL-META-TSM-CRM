function generate_latex_report_integrado(res_pbi, res_ct, params)
% GENERATE_LATEX_REPORT_INTEGRADO
% Genera un unico archivo LaTeX con los resultados del PIB y del CTSNF.

if nargin < 3 || ~isstruct(params)
    params = struct();
end
if ~isfield(params, "latex_dir") || isempty(params.latex_dir)
    params.latex_dir = "latex";
end
if ~exist(params.latex_dir, "dir")
    mkdir(params.latex_dir);
end

tex_file = fullfile(params.latex_dir, "reporte_MS_integrado.tex");
fid = fopen(tex_file, "w", "n", "UTF-8");
if fid == -1
    error("No se pudo crear el archivo: %s", tex_file);
end
cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>

w = @(s) fprintf(fid, "%s\n", s);
fmt4   = @(x) sprintf("%.4f", x);
fmt1   = @(x) sprintf("%.1f", x);
fmtpct = @(x) sprintf("%.2f\\%%", 100*x);

pbi = res_pbi;
ct  = res_ct;

if ~isfield(pbi, "pms_rec"),  pbi.pms_rec  = pbi.ms.sp_rec(end); end
if ~isfield(pbi, "pms_exp"),  pbi.pms_exp  = pbi.ms.sp_exp(end); end
if ~isfield(pbi, "pms_auge"), pbi.pms_auge = pbi.ms.sp_auge(end); end
if ~isfield(ct,  "pms_rec"),  ct.pms_rec   = ct.ms.sp_rec(end); end
if ~isfield(ct,  "pms_exp"),  ct.pms_exp   = ct.ms.sp_exp(end); end
if ~isfield(ct,  "pms_auge"), ct.pms_auge  = ct.ms.sp_auge(end); end

% Preambulo
w("\documentclass[11pt,a4paper]{article}");
w("\usepackage[utf8]{inputenc}");
w("\usepackage[T1]{fontenc}");
w("\usepackage[spanish]{babel}");
w("\usepackage{lmodern}");
w("\usepackage{geometry}");
w("\usepackage{booktabs}");
w("\usepackage{float}");
w("\usepackage{amsmath,amssymb}");
w("\usepackage{hyperref}");
w("\geometry{margin=2.5cm}");
w("\hypersetup{colorlinks=true, linkcolor=blue!70!black, citecolor=blue!70!black, urlcolor=blue}");
w("");
w("\begin{document}");
w("");

% Portada
w("\begin{titlepage}");
w("  \centering");
w("  \vspace*{2cm}");
w("  {\LARGE\bfseries Ciclo Económico del PIB y del CTSNF Real\\[0.5em]}");
w("  {\large\itshape Modelo Markov Switching MS-MH(3) con filtro Christiano-Fitzgerald asimétrico}");
w("");
w("  \vspace{1.0cm}");
w("  {\large Joan Valderrama Inonán\\[0.25cm]");
w("   UNAC --- Macroeconometría}");
w("");
fprintf(fid, "  {\\normalsize \\textbf{Período PIB:} %s -- %s}\\\\[0.15cm]\n", pbi.first_date_str, pbi.last_date_str);
fprintf(fid, "  {\\normalsize \\textbf{Período CTSNF:} %s -- %s}\\\\[0.15cm]\n", ct.first_date_str, ct.last_date_str);
fprintf(fid, "  {\\normalsize \\textbf{Fecha de estimación:} %s}\n", datestr(now, 'dd/mm/yyyy'));
w("");
w("  \vfill");
w("  {\small Elaborado con MATLAB R2019b+ $|$ Hamilton (1989) $|$ Kim \& Nelson (1999) $|$ Christiano \& Fitzgerald (2003)}");
w("\end{titlepage}");
w("");

% Abstract
w("\begin{abstract}");
w("\noindent Este reporte integra dos estimaciones del modelo MS-MH(3): una para el PIB real y otra para el CTSNF real. En ambos casos se extrae el ciclo con el filtro de banda Christiano-Fitzgerald asimétrico y luego se estima la cadena de regímenes mediante el algoritmo EM con filtro de Hamilton y suavizador de Kim. Se presentan estadísticas descriptivas, parámetros por régimen, matriz de transición, bondad de ajuste y probabilidades suavizadas del último período.");
w("\end{abstract}");
w("");
w("\tableofcontents");
w("\newpage");
w("");

% Metodologia
w("\section{Modelo Teórico}");
w("");
w("Se trabaja con la tasa de crecimiento trimestral de la serie en logaritmos, $100\,\Delta\log(y_t)$, y sobre esa transformación se aplica el filtro de banda de paso de Christiano y Fitzgerald (2003) para obtener el componente cíclico.");
w("");
w("\begin{equation}");
w("  c_t = B_0 y_t + \sum_{k=1}^{t-1} B_k y_{t-k} + \sum_{k=1}^{T-t} B_k y_{t+k} - a_{T-t}y_T - b_{t-1}y_1");
w("\end{equation}");
w("");
w("El ciclo extraído se modela como $c_t = \mu_{s_t} + \sigma_{s_t}\varepsilon_t$, con $\varepsilon_t \overset{iid}{\sim} \mathcal{N}(0,1)$, y el estado no observable $s_t \in \{1,2,3\}$ sigue una cadena de Markov de primer orden.");

% PIB
w("\newpage");
w("\section{Resultados: PIB real}");
w("");
[~, idxp] = max([pbi.pms_rec, pbi.pms_exp, pbi.pms_auge]);
domp = ["recesión", "expansión", "auge"];
fprintf(fid, "El PIB termina la muestra en un régimen predominantemente \\textbf{%s}, con una probabilidad suavizada de %s. El valor del ciclo $c_T = %s$ se ubica entre los umbrales de referencia (recesión: $%s$; auge: $%s$).\\par\n", ...
    char(domp(idxp)), fmtpct(max([pbi.pms_rec, pbi.pms_exp, pbi.pms_auge])), fmt4(pbi.cy_last), fmt4(pbi.umbral_rec), fmt4(pbi.umbral_auge));

w("\begin{table}[H]"); w("\centering");
w("\caption{Estadísticas descriptivas del ciclo CF -- PIB real}");
w("\begin{tabular}{lc}"); w("\toprule"); w("Estadística & Valor \\"); w("\midrule");
fprintf(fid, "Observaciones & %d \\\\\n", pbi.cy_nobs);
fprintf(fid, "Período & %s -- %s \\\\\n", pbi.first_date_str, pbi.last_date_str);
fprintf(fid, "Media & %s \\\\\n", fmt4(pbi.cy_mean));
fprintf(fid, "Desviación estándar & %s \\\\\n", fmt4(pbi.cy_sd));
fprintf(fid, "Umbral recesión (p33) & %s \\\\\n", fmt4(pbi.umbral_rec));
fprintf(fid, "Umbral auge (p67) & %s \\\\\n", fmt4(pbi.umbral_auge));
fprintf(fid, "Último valor observado ($c_T$) & %s \\\\\n", fmt4(pbi.cy_last));
w("\bottomrule"); w("\end{tabular}"); w("\end{table}"); w("");

w("\begin{table}[H]"); w("\centering");
w("\caption{Parámetros por régimen -- PIB real}");
w("\begin{tabular}{lccccc}"); w("\toprule");
w("Régimen & $\hat{\mu}_k$ & $\hat{\sigma}_k$ & $\hat{p}_{kk}$ & Dur. esperada & $N$ periodos \\"); w("\midrule");
fprintf(fid, "Recesión & %s & %s & %s & %s trim. & %d \\\\\n", fmt4(pbi.ms.mu_rec), fmt4(pbi.ms.sigma_rec), fmt4(pbi.ms.p_rr), fmt1(pbi.ms.dur_rec), pbi.ms.n_rec);
fprintf(fid, "Expansión & %s & %s & %s & %s trim. & %d \\\\\n", fmt4(pbi.ms.mu_exp), fmt4(pbi.ms.sigma_exp), fmt4(pbi.ms.p_ee), fmt1(pbi.ms.dur_exp), pbi.ms.n_exp);
fprintf(fid, "Auge & %s & %s & %s & %s trim. & %d \\\\\n", fmt4(pbi.ms.mu_auge), fmt4(pbi.ms.sigma_auge), fmt4(pbi.ms.p_aa), fmt1(pbi.ms.dur_auge), pbi.ms.n_auge);
w("\bottomrule"); w("\end{tabular}"); w("\end{table}"); w("");

w("\begin{table}[H]"); w("\centering");
w("\caption{Matriz de transición estimada -- PIB real}");
w("\begin{tabular}{lccc}"); w("\toprule");
w("$s_{t-1} \backslash s_t$ & Recesión & Expansión & Auge \\"); w("\midrule");
fprintf(fid, "Recesión & %s & %s & %s \\\\\n", fmt4(pbi.ms.p_rr), fmt4(pbi.ms.p_re), fmt4(pbi.ms.p_ra));
fprintf(fid, "Expansión & %s & %s & %s \\\\\n", fmt4(pbi.ms.p_er), fmt4(pbi.ms.p_ee), fmt4(pbi.ms.p_ea));
fprintf(fid, "Auge & %s & %s & %s \\\\\n", fmt4(pbi.ms.p_ar), fmt4(pbi.ms.p_ae), fmt4(pbi.ms.p_aa));
w("\bottomrule"); w("\end{tabular}"); w("\end{table}"); w("");

w("\begin{table}[H]"); w("\centering");
w("\caption{Bondad de ajuste -- PIB real}");
w("\begin{tabular}{lc}"); w("\toprule"); w("Criterio & Valor \\"); w("\midrule");
fprintf(fid, "Log-verosimilitud & %s \\\\\n", fmt4(pbi.ms.loglik));
fprintf(fid, "AIC & %s \\\\\n", fmt4(pbi.ms.aic));
fprintf(fid, "BIC & %s \\\\\n", fmt4(pbi.ms.bic));
fprintf(fid, "Parámetros libres & %d \\\\\n", pbi.ms.n_params);
fprintf(fid, "Convergencia & %s \\\\\n", pbi.ms.converged_str);
fprintf(fid, "Iteraciones & %d \\\\\n", pbi.ms.n_iter);
w("\bottomrule"); w("\end{tabular}"); w("\end{table}"); w("");

w("\begin{table}[H]"); w("\centering");
fprintf(fid, "  \\caption{Probabilidades suavizadas al último período -- PIB real}\n");
w("\begin{tabular}{lcc}"); w("\toprule"); w("Régimen & $P(s_T = k \mid \Omega_T)$ & Interpretación \\"); w("\midrule");
fprintf(fid, "Recesión & %s & Brecha del producto negativa ($c_T < %s$) \\\\\n", fmtpct(pbi.pms_rec), fmt4(pbi.umbral_rec));
fprintf(fid, "Expansión & %s & Brecha del producto moderada \\\\\n", fmtpct(pbi.pms_exp));
fprintf(fid, "Auge & %s & Brecha del producto positiva ($c_T > %s$) \\\\\n", fmtpct(pbi.pms_auge), fmt4(pbi.umbral_auge));
w("\midrule");
w("Total & 100.00\% & \\");
w("\bottomrule"); w("\end{tabular}"); w("\end{table}"); w("");
fprintf(fid, "La duración esperada del régimen de recesión es de %s trimestres, mientras que la expansión dura %s trimestres y el auge %s trimestres.\\par\n", fmt1(pbi.ms.dur_rec), fmt1(pbi.ms.dur_exp), fmt1(pbi.ms.dur_auge));

% CTSNF
w("\newpage");
w("\section{Resultados: CTSNF real}");
w("");
[~, idxc] = max([ct.pms_rec, ct.pms_exp, ct.pms_auge]);
domc = ["recesión", "expansión", "auge"];
fprintf(fid, "El CTSNF termina la muestra en un régimen predominantemente \\textbf{%s}, con una probabilidad suavizada de %s. El valor del ciclo $c_T = %s$ se ubica entre los umbrales de referencia (recesión: $%s$; auge: $%s$).\\par\n", ...
    char(domc(idxc)), fmtpct(max([ct.pms_rec, ct.pms_exp, ct.pms_auge])), fmt4(ct.cy_last), fmt4(ct.umbral_rec), fmt4(ct.umbral_auge));

w("\begin{table}[H]"); w("\centering");
w("\caption{Estadísticas descriptivas del ciclo CF -- CTSNF real}");
w("\begin{tabular}{lc}"); w("\toprule"); w("Estadística & Valor \\"); w("\midrule");
fprintf(fid, "Observaciones & %d \\\\\n", ct.cy_nobs);
fprintf(fid, "Período & %s -- %s \\\\\n", ct.first_date_str, ct.last_date_str);
fprintf(fid, "Media & %s \\\\\n", fmt4(ct.cy_mean));
fprintf(fid, "Desviación estándar & %s \\\\\n", fmt4(ct.cy_sd));
fprintf(fid, "Umbral recesión (p33) & %s \\\\\n", fmt4(ct.umbral_rec));
fprintf(fid, "Umbral auge (p67) & %s \\\\\n", fmt4(ct.umbral_auge));
fprintf(fid, "Último valor observado ($c_T$) & %s \\\\\n", fmt4(ct.cy_last));
w("\bottomrule"); w("\end{tabular}"); w("\end{table}"); w("");

w("\begin{table}[H]"); w("\centering");
w("\caption{Parámetros por régimen -- CTSNF real}");
w("\begin{tabular}{lccccc}"); w("\toprule");
w("Régimen & $\hat{\mu}_k$ & $\hat{\sigma}_k$ & $\hat{p}_{kk}$ & Dur. esperada & $N$ periodos \\"); w("\midrule");
fprintf(fid, "Recesión & %s & %s & %s & %s trim. & %d \\\\\n", fmt4(ct.ms.mu_rec), fmt4(ct.ms.sigma_rec), fmt4(ct.ms.p_rr), fmt1(ct.ms.dur_rec), ct.ms.n_rec);
fprintf(fid, "Expansión & %s & %s & %s & %s trim. & %d \\\\\n", fmt4(ct.ms.mu_exp), fmt4(ct.ms.sigma_exp), fmt4(ct.ms.p_ee), fmt1(ct.ms.dur_exp), ct.ms.n_exp);
fprintf(fid, "Auge & %s & %s & %s & %s trim. & %d \\\\\n", fmt4(ct.ms.mu_auge), fmt4(ct.ms.sigma_auge), fmt4(ct.ms.p_aa), fmt1(ct.ms.dur_auge), ct.ms.n_auge);
w("\bottomrule"); w("\end{tabular}"); w("\end{table}"); w("");

w("\begin{table}[H]"); w("\centering");
w("\caption{Matriz de transición estimada -- CTSNF real}");
w("\begin{tabular}{lccc}"); w("\toprule");
w("$s_{t-1} \backslash s_t$ & Recesión & Expansión & Auge \\"); w("\midrule");
fprintf(fid, "Recesión & %s & %s & %s \\\\\n", fmt4(ct.ms.p_rr), fmt4(ct.ms.p_re), fmt4(ct.ms.p_ra));
fprintf(fid, "Expansión & %s & %s & %s \\\\\n", fmt4(ct.ms.p_er), fmt4(ct.ms.p_ee), fmt4(ct.ms.p_ea));
fprintf(fid, "Auge & %s & %s & %s \\\\\n", fmt4(ct.ms.p_ar), fmt4(ct.ms.p_ae), fmt4(ct.ms.p_aa));
w("\bottomrule"); w("\end{tabular}"); w("\end{table}"); w("");

w("\begin{table}[H]"); w("\centering");
w("\caption{Bondad de ajuste -- CTSNF real}");
w("\begin{tabular}{lc}"); w("\toprule"); w("Criterio & Valor \\"); w("\midrule");
fprintf(fid, "Log-verosimilitud & %s \\\\\n", fmt4(ct.ms.loglik));
fprintf(fid, "AIC & %s \\\\\n", fmt4(ct.ms.aic));
fprintf(fid, "BIC & %s \\\\\n", fmt4(ct.ms.bic));
fprintf(fid, "Parámetros libres & %d \\\\\n", ct.ms.n_params);
fprintf(fid, "Convergencia & %s \\\\\n", ct.ms.converged_str);
fprintf(fid, "Iteraciones & %d \\\\\n", ct.ms.n_iter);
w("\bottomrule"); w("\end{tabular}"); w("\end{table}"); w("");

w("\begin{table}[H]"); w("\centering");
fprintf(fid, "  \\caption{Probabilidades suavizadas al último período -- CTSNF real}\n");
w("\begin{tabular}{lcc}"); w("\toprule"); w("Régimen & $P(s_T = k \mid \Omega_T)$ & Interpretación \\"); w("\midrule");
fprintf(fid, "Recesión & %s & Brecha del producto negativa ($c_T < %s$) \\\\\n", fmtpct(ct.pms_rec), fmt4(ct.umbral_rec));
fprintf(fid, "Expansión & %s & Brecha del producto moderada \\\\\n", fmtpct(ct.pms_exp));
fprintf(fid, "Auge & %s & Brecha del producto positiva ($c_T > %s$) \\\\\n", fmtpct(ct.pms_auge), fmt4(ct.umbral_auge));
w("\midrule");
w("Total & 100.00\% & \\");
w("\bottomrule"); w("\end{tabular}"); w("\end{table}"); w("");
fprintf(fid, "La duración esperada del régimen de recesión es de %s trimestres, mientras que la expansión dura %s trimestres y el auge %s trimestres.\\par\n", fmt1(ct.ms.dur_rec), fmt1(ct.ms.dur_exp), fmt1(ct.ms.dur_auge));

% Comparación
w("\newpage");
w("\section{Comparación Sintética}");
w("");
w("\begin{table}[H]"); w("\centering");
w("\caption{Comparación resumida entre PIB y CTSNF}");
w("\begin{tabular}{lcc}"); w("\toprule");
w("Indicador & PIB real & CTSNF real \\"); w("\midrule");
fprintf(fid, "Última fecha & %s & %s \\\\\n", pbi.last_date_str, ct.last_date_str);
fprintf(fid, "Último ciclo & %s & %s \\\\\n", fmt4(pbi.cy_last), fmt4(ct.cy_last));
fprintf(fid, "Prob. expansión final & %s & %s \\\\\n", fmtpct(pbi.pms_exp), fmtpct(ct.pms_exp));
fprintf(fid, "Log-verosimilitud & %s & %s \\\\\n", fmt4(pbi.ms.loglik), fmt4(ct.ms.loglik));
fprintf(fid, "AIC & %s & %s \\\\\n", fmt4(pbi.ms.aic), fmt4(ct.ms.aic));
fprintf(fid, "BIC & %s & %s \\\\\n", fmt4(pbi.ms.bic), fmt4(ct.ms.bic));
fprintf(fid, "Duración esperada expansión & %s & %s \\\\\n", fmt1(pbi.ms.dur_exp), fmt1(ct.ms.dur_exp));
w("\bottomrule"); w("\end{tabular}"); w("\end{table}"); w("");
w("Ambas series terminan la muestra en un régimen dominado por la expansión. La lectura económica debe entenderse como una clasificación probabilística del ciclo, no como una regla determinística.");
w("");

% Referencias
w("\newpage");
w("\begin{thebibliography}{99}");
w("\bibitem{Hamilton1989} Hamilton, J.D. (1989). A New Approach to the Economic Analysis of Nonstationary Time Series and the Business Cycle. \textit{Econometrica}, 57(2), 357--384.");
w("\bibitem{KimNelson1999} Kim, C.J. \& Nelson, C.R. (1999). \textit{State-Space Models with Regime Switching: Classical and Gibbs-Sampling Approaches with Applications}. MIT Press.");
w("\bibitem{Kim1994} Kim, C.J. (1994). Dynamic linear models with Markov-switching. \textit{Journal of Econometrics}, 60(1--2), 1--22.");
w("\bibitem{CF2003} Christiano, L.J. \& Fitzgerald, T.J. (2003). The Band Pass Filter. \textit{International Economic Review}, 44(2), 435--465.");
w("\end{thebibliography}");
w("\end{document}");

fprintf("Reporte unificado escrito en: %s\n", tex_file);
end
