function result = estimate_markov_switching(y, params)
% ESTIMATE_MARKOV_SWITCHING  Estimacion MS-MH(K) por algoritmo EM
%
% Estima un modelo Markov Switching con K regimenes, media y varianza
% dependientes del regimen, mediante el algoritmo Expectacion-Maximizacion
% (EM) con multiples reinicios para evitar optimos locales.
%
% MODELO:
%   y_t = mu(s_t) + sigma(s_t) * eps_t,   eps_t ~ iid N(0,1)
%   s_t en {1,...,K},  P(s_t=j | s_{t-1}=i) = p_{ij}
%   P_trans = [p_{ij}] matriz de transicion (K x K)
%
% ESTIMACION:
%   Paso E: Filtro de Hamilton (adelante) + Suavizador de Kim (atras)
%   Paso M: Actualizacion de mu_k, sigma_k, p_{ij} en forma cerrada
%
% REFERENCIAS:
%   Hamilton (1989) Econometrica 57(2):357-384
%   Kim (1994) J. Economic Dynamics and Control 18:443-462
%   Kim & Nelson (1999) State-Space Models. MIT Press. Cap. 4-5.
%   Krolzig (1997) Markov-Switching VAR. Springer. Cap. 2.
%
% SINTAXIS:
%   result = estimate_markov_switching(y, params)
%
% ENTRADAS:
%   y       - [Tx1] serie del ciclo
%   params  - estructura con campos:
%               .states      numero de regimenes K
%               .maxiter     iteraciones maximas EM
%               .tol         tolerancia de convergencia (log-lik)
%               .n_restarts  numero de reinicios aleatorios
%               .seed        semilla (ya establecida en main)
%
% SALIDA: estructura result con todos los estimados y probabilidades

y = y(:);
T = length(y);
K = params.states;

best_loglik = -Inf;
best_result = [];

fprintf('      ');

for restart = 1:params.n_restarts
    fprintf('r%d ', restart);
    
    % --- Inicializacion aleatoria ---
    [mu0, sigma0, P0, pi0] = initialize_ms(y, K, restart);
    
    % --- Algoritmo EM ---
    [res_tmp] = em_algorithm(y, mu0, sigma0, P0, pi0, params.maxiter, params.tol);
    
    if res_tmp.loglik > best_loglik
        best_loglik = res_tmp.loglik;
        best_result = res_tmp;
    end
end
fprintf('\n');

result = best_result;

% Calcular criterios de informacion
% Parametros libres: K medias + K varianzas + K*(K-1) probabilidades de transicion
n_params = K + K + K*(K-1);
result.n_params = n_params;
result.aic = -2*result.loglik + 2*n_params;
result.bic = -2*result.loglik + n_params*log(T);

% Probabilidades filtradas y suavizadas ya estan en result
% Almacenar serie original y dimension
result.y = y;
result.T = T;
result.K = K;

end

% =========================================================================
% FUNCION INTERNA: INICIALIZACION
% =========================================================================
function [mu0, sigma0, P0, pi0] = initialize_ms(y, K, restart)
% Inicializa parametros del MS de forma reproducible pero variada

T = length(y);
rng(100 + restart);  % semilla unica por restart

% Estrategia: particionar la muestra en K cuantiles para obtener mu iniciales
% quantile() devuelve fila cuando el input es fila; forzar columna antes
% de cualquier aritmetica para evitar broadcasting [1xK]+[Kx1]->[KxK]
% en MATLAB R2021b+ con implicit expansion habilitado.
q = quantile(y, linspace(0, 1, K+2));
q = q(2:end-1);
q = q(:);         % [K x 1] — garantizado independientemente de la version

% Perturbar con ruido para variedad entre reinicios
mu0    = q + 0.1*std(y)*randn(K,1);   % [K x 1] + [K x 1] -> [K x 1]
mu0    = sort(mu0);                    % sort de columna devuelve columna
sigma0 = std(y) * (0.5 + rand(K,1));  % [K x 1]

% Matriz de transicion: diagonalmente dominante (persistencia alta)
P0 = rand(K, K);
P0 = P0 .* (ones(K) + 4*eye(K));   % favorecer diagonal
P0 = bsxfun(@rdivide, P0, sum(P0, 2));  % normalizar filas

% Distribucion inicial: estacionaria de P0
try
    [V, D] = eig(P0');
    [~, idx] = max(diag(D));
    pi0 = abs(V(:, idx));
    pi0 = pi0 / sum(pi0);
catch
    pi0 = ones(K,1)/K;
end

end

% =========================================================================
% FUNCION INTERNA: ALGORITMO EM COMPLETO
% =========================================================================
function result = em_algorithm(y, mu, sigma, P_trans, pi_init, maxiter, tol)

T  = length(y);
K  = length(mu);
loglik_prev = -Inf;
converged   = false;

for iter = 1:maxiter
    
    % --- PASO E: Filtro de Hamilton (adelante) ---
    [xi_filtered, xi_pred, loglik] = hamilton_filter(y, mu, sigma, P_trans, pi_init);
    
    % --- PASO E: Suavizador de Kim (atras) ---
    xi_smoothed = kim_smoother(xi_filtered, xi_pred, P_trans);
    
    % Verificar convergencia
    if abs(loglik - loglik_prev) < tol && iter > 1
        converged = true;
        break;
    end
    loglik_prev = loglik;
    
    % --- PASO M: Actualizar parametros ---
    
    % Probabilidades de transicion conjuntas P(s_t=j, s_{t-1}=i | Y_T)
    % Segun Kim & Nelson (1999), ec. (4.20)
    xi_joint = compute_joint_probs(xi_smoothed, xi_filtered, xi_pred, P_trans, y, mu, sigma);
    
    % Actualizar matriz de transicion
    for i = 1:K
        for j = 1:K
            P_trans(i,j) = sum(xi_joint(2:T, i, j)) / sum(xi_smoothed(1:T-1, i));
        end
    end
    % Renormalizar filas
    P_trans = bsxfun(@rdivide, P_trans, sum(P_trans, 2) + 1e-300);
    
    % Actualizar medias y desviaciones estandar
    for k = 1:K
        w = xi_smoothed(:, k);
        w_sum = sum(w) + 1e-300;
        mu(k)    = sum(w .* y) / w_sum;
        sigma(k) = sqrt(sum(w .* (y - mu(k)).^2) / w_sum);
        sigma(k) = max(sigma(k), 1e-6);  % cota inferior para estabilidad
    end
    % Garantizar orientacion columna tras las asignaciones elemento a elemento
    % (mu(k)=... puede convertir el vector a fila en algunas versiones de MATLAB)
    mu    = mu(:);
    sigma = sigma(:);
    
    % Actualizar distribucion inicial (prob. suavizada en t=1)
    pi_init = xi_smoothed(1, :)';
    pi_init = pi_init / (sum(pi_init) + 1e-300);
    
end

% Corrida final para obtener probabilidades con parametros convergidos
[xi_filtered, xi_pred, loglik] = hamilton_filter(y, mu, sigma, P_trans, pi_init);
xi_smoothed = kim_smoother(xi_filtered, xi_pred, P_trans);

% Empaquetar resultado
result.mu         = mu;
result.sigma      = sigma;
result.P_trans    = P_trans;
result.pi_init    = pi_init;
result.loglik     = loglik;
result.xi_filt    = xi_filtered;
result.xi_smooth  = xi_smoothed;
result.converged  = converged;
result.converged_str = ternary_str(converged, 'SI', 'NO (maxiter alcanzado)');
result.n_iter     = iter;

end

% =========================================================================
% FILTRO DE HAMILTON (ADELANTE)
% =========================================================================
function [xi_filt, xi_pred, loglik] = hamilton_filter(y, mu, sigma, P_trans, pi_init)
% Implementa el filtro de probabilidades de Hamilton (1989), ec. (22.4.5)
%
% xi_filt(t,k) = P(s_t=k | Y_t)   probabilidad filtrada
% xi_pred(t,k) = P(s_t=k | Y_{t-1}) probabilidad predicha
% loglik       = log-verosimilitud

T = length(y);
K = length(mu);

% Forzar orientacion columna para mu y sigma ANTES del bucle.
% normpdf(escalar, vec_col, vec_col) devuelve [K x 1]; si mu o sigma
% llegaran como fila el resultado puede ser escalar o fila segun version
% de MATLAB. La conversion aqui garantiza [K x 1] -> eta(:)' -> [1 x K].
mu    = mu(:);      % [K x 1]
sigma = sigma(:);   % [K x 1]

xi_filt = zeros(T, K);
xi_pred = zeros(T, K);
loglik  = 0;

xi_prev = pi_init(:)';   % [1 x K]

for t = 1:T
    % Prediccion: P(s_t=k | Y_{t-1})
    xi_p = xi_prev * P_trans;   % [1 x K]
    xi_pred(t,:) = xi_p;

    % Densidad condicional normal para cada regimen
    % normpdf con mu,sigma columna -> eta es [K x 1] -> forzar a [1 x K]
    eta = normpdf(y(t), mu, sigma);   % [K x 1]
    eta = eta(:)';                     % [1 x K]  — garantizado

    % Actualizacion bayesiana: P(s_t=k | Y_t) proporcional a eta * xi_pred
    joint    = xi_p .* eta;   % [1 x K] .* [1 x K] — sin ambiguedad
    lik_t    = sum(joint);
    
    if lik_t < 1e-300
        lik_t = 1e-300;
    end
    
    xi_filt(t,:) = joint / lik_t;
    loglik = loglik + log(lik_t);
    
    xi_prev = xi_filt(t,:);
end

end

% =========================================================================
% SUAVIZADOR DE KIM (ATRAS)
% =========================================================================
function xi_smooth = kim_smoother(xi_filt, xi_pred, P_trans)
% Implementa el suavizador de Kim (1994), ec. (4.19) en Kim & Nelson (1999)
%
% xi_smooth(t,k) = P(s_t=k | Y_T)   probabilidad suavizada (usa toda la muestra)
%
% Recurrencia hacia atras:
%   P(s_t=j | Y_T) = sum_k [ P(s_{t+1}=k | Y_T) * P_jk * P(s_t=j | Y_t) / P(s_{t+1}=k | Y_t) ]

[T, K] = size(xi_filt);
xi_smooth = zeros(T, K);
xi_smooth(T,:) = xi_filt(T,:);   % condicion inicial: ultimo periodo

for t = T-1:-1:1
    for j = 1:K
        s = 0;
        for k = 1:K
            if xi_pred(t+1, k) > 1e-300
                s = s + xi_smooth(t+1, k) * P_trans(j,k) * xi_filt(t,j) / xi_pred(t+1,k);
            end
        end
        xi_smooth(t,j) = s;
    end
    % Renormalizar para evitar acumulacion numerica
    row_sum = sum(xi_smooth(t,:));
    if row_sum > 1e-300
        xi_smooth(t,:) = xi_smooth(t,:) / row_sum;
    end
end

end

% =========================================================================
% PROBABILIDADES CONJUNTAS (para paso M de la transicion)
% =========================================================================
function xi_joint = compute_joint_probs(xi_smooth, xi_filt, xi_pred, P_trans, y, mu, sigma)
% P(s_t=j, s_{t-1}=i | Y_T)  [T x K x K]
% Kim & Nelson (1999), ec. (4.20)

T = length(y);
K = length(mu);
xi_joint = zeros(T, K, K);

% Forzar columna para consistencia con hamilton_filter
mu    = mu(:);
sigma = sigma(:);

for t = 2:T
    % eta no se usa directamente en este bloque; se mantiene por simetria
    % y por si en el futuro se vectoriza el calculo de xi_joint.
    for i = 1:K
        for j = 1:K
            num = xi_smooth(t,j) * P_trans(i,j) * xi_filt(t-1,i);
            den = xi_pred(t,j);
            if den > 1e-300
                xi_joint(t, i, j) = num / den;
            end
        end
    end
end

end

% =========================================================================
% UTILIDAD: operador ternario para strings
% =========================================================================
function s = ternary_str(cond, s_true, s_false)
if cond
    s = s_true;
else
    s = s_false;
end
end
