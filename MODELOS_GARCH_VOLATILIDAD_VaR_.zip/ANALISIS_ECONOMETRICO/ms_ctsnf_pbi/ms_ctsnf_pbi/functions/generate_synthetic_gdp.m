function [dates, gdp_log] = generate_synthetic_gdp(T)
% GENERATE_SYNTHETIC_GDP  PIB sintetico trimestral para demostracion
%
% Genera una serie de T trimestres con tendencia estocastica y componente
% ciclico gobernado por una cadena de Markov de 3 regimenes calibrada
% aproximadamente sobre el ciclo del PIB de EE.UU. (Hamilton 1989).
%
% SINTAXIS:
%   [dates, gdp_log] = generate_synthetic_gdp(T)
%
% SALIDAS:
%   dates   - [Tx1] fechas en formato datenum (trimestrales desde 1960-Q1)
%   gdp_log - [Tx1] log del PIB real sintetico

if nargin < 1, T = 180; end
rng(42);

% Fechas trimestrales
t0    = datenum(1960,1,1);
dates = t0 + (0:T-1)' * 91;

% Tendencia (random walk con deriva)
trend = cumsum(0.005 + 0.003*randn(T,1));

% Parametros verdaderos del MS(3)
mu_true    = [-0.020;  0.008;  0.030];
sigma_true = [ 0.025;  0.012;  0.018];
P_true = [0.85 0.10 0.05;
          0.05 0.88 0.07;
          0.04 0.08 0.88];

% Simular cadena de Markov
state = zeros(T,1);
state(1) = 2;
for t = 2:T
    u  = rand;
    cs = cumsum(P_true(state(t-1), :));
    state(t) = find(u <= cs, 1, 'first');
end

% Ciclo
cycle_true = mu_true(state) + sigma_true(state) .* randn(T,1);

% log-PIB = tendencia + ciclo acumulado (suavizado)
gdp_log = trend + cumsum(cycle_true)*0.3;
gdp_log = gdp_log - gdp_log(1) + log(2000);

fprintf('      [Sintetico] T=%d | Rec=%d  Exp=%d  Auge=%d periodos\n', ...
        T, sum(state==1), sum(state==2), sum(state==3));
end
