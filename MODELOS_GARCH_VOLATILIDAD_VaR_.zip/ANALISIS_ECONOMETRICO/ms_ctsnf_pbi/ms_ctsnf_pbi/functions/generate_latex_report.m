function generate_latex_report(res, params)
% GENERATE_LATEX_REPORT  Genera el archivo .tex del reporte de resultados MS
%
% Produce un documento LaTeX completo con:
%   - Portada y abstract
%   - Descripcion del modelo y metodologia
%   - Tablas de resultados (parametros, transicion, duraciones, probabs.)
%   - Inclusion de las 4 figuras generadas
%   - Referencias bibliograficas
%
% CORRECCIONES v1.2 -> v1.3:
%   - Corregida expresion matricial invalida en bloque de interpretacion
%     economica. La probabilidad del regimen dominante ahora se extrae
%     directamente como probs_vec(reg_dom) en lugar de la multiplicacion
%     matricial incorrecta que producia resultados erroneos.
%   - Eliminada funcion auxiliar ternary_str2 duplicada (ahora es local).

if ~exist(params.latex_dir, 'dir'), mkdir(params.latex_dir); end

tex_file = fullfile(params.latex_dir, 'reporte_MS_ciclo.tex');
fid = fopen(tex_file, 'w', 'n', 'UTF-8');
if fid == -1
    error('No se pudo crear el archivo: %s', tex_file);
end

ms  = res.ms;
last_date_str  = datenum2qstr(res.dates(end));
first_date_str = datenum2qstr(res.dates(1));

% Helper: ruta relativa de figuras desde latex/
fig_rel = '../output';

w = @(s) fprintf(fid, '%s\n', s);   % shorthand para escribir una linea

% =========================================================================
% PREAMBULO
% =========================================================================
w('\documentclass[12pt,a4paper]{article}');
w('\usepackage[utf8]{inputenc}');
w('\usepackage[T1]{fontenc}');
w('\usepackage[spanish]{babel}');
w('\usepackage{amsmath,amssymb,amsfonts}');
w('\usepackage{booktabs}');
w('\usepackage{graphicx}');
w('\usepackage{float}');
w('\usepackage{caption}');
w('\usepackage{subcaption}');
w('\usepackage{geometry}');
w('\usepackage{hyperref}');
w('\usepackage{xcolor}');
w('\usepackage{natbib}');
w('\usepackage{setspace}');
w('\usepackage{lmodern}');
w('');
w('\geometry{margin=2.5cm}');
w('\onehalfspacing');
w('\hypersetup{colorlinks=true, linkcolor=blue!70!black, citecolor=blue!70!black, urlcolor=blue}');
w('');

% =========================================================================
% INICIO DOCUMENTO
% =========================================================================
w('\begin{document}');
w('');

% --- Portada ---
w('\begin{titlepage}');
w('  \centering');
w('  \vspace*{2cm}');
w('  {\LARGE\bfseries Ciclo Econ\''omico del PIB y Probabilidades de R\''egimen\\[0.5em]');
w('   Modelo Markov Switching MS-MH(3)\\[0.3em]}');
w('  \vspace{0.5cm}');
w('  {\large\itshape Filtro Christiano-Fitzgerald Asim\''etrico + Hamilton (1989)}');
w('  \vspace{1.5cm}\\');
fprintf(fid, '  {\\large Joan Valderrama Inon\\''an \\\\[0.3em]\n');
w('   UNAC --- Macroeconometr\''ia}');
w('  \vspace{1cm}\\');
fprintf(fid, '  {\\normalsize \\textbf{Per\\''iodo analizado:} %s -- %s}\\\\[0.3em]\n', first_date_str, last_date_str);
fprintf(fid, '  {\\normalsize \\textbf{Fecha de estimaci\\''on:} %s}\n', datestr(now,'dd/mm/yyyy'));
w('  \vfill');
w('  {\small Elaborado con MATLAB R2019b+ $|$ Hamilton (1989) $|$ Kim \& Nelson (1999)}');
w('\end{titlepage}');
w('');

% --- Abstract ---
w('\begin{abstract}');
w('\noindent');
w(['Este reporte presenta la estimaci\''on del ciclo econ\''omico del PIB real ' ...
   'mediante el filtro de banda Christiano-Fitzgerald asim\''etrico (CF), y la ' ...
   'identificaci\''on de tres reg\''imenes del ciclo ---recesi\''on, expansi\''on y auge--- ' ...
   'mediante un modelo de Markov Switching con media y varianza dependientes del r\''egimen ' ...
   '[MS-MH(3)]. La estimaci\''on se realiza por el algoritmo de Esperanza-Maximizaci\''on ' ...
   '(EM) con el filtro de Hamilton (adelante) y el suavizador de Kim (atr\''as). ' ...
   'Los resultados reportan probabilidades suavizadas, par\''ametros estructurales, ' ...
   'duraciones esperadas de cada r\''egimen y la clasificaci\''on hist\''orica del ciclo.']);
w('\end{abstract}');
w('');
w('\tableofcontents');
w('\newpage');
w('');

% =========================================================================
% SECCION 1: MODELO
% =========================================================================
w('\section{Modelo Te\''orico}');
w('');
w('\subsection{Filtro Christiano-Fitzgerald Asim\''etrico}');
w('');
w(['El componente c\''iclico del PIB real, $c_t$, se extrae del logaritmo del PIB, ' ...
   '$y_t = \log(\text{PIB}_t)$, mediante el filtro de banda de paso de \citet{CF2003}. ' ...
   'El filtro asim\''etrico aplica pesos $B_k$ calibrados para aislar ' ...
   'frecuencias entre $p_\ell$ y $p_u$ trimestres:']);
w('');
w('\begin{equation}');
w('  c_t = B_0 y_t + \sum_{k=1}^{t-1} B_k y_{t-k} + \sum_{k=1}^{T-t} B_k y_{t+k}');
w('  - a_{T-t}\,y_T - b_{t-1}\,y_1');
w('\end{equation}');
w('');
fprintf(fid, 'donde $B_0 = (\\omega_h - \\omega_\\ell)/\\pi$, $B_k = [\\sin(k\\omega_h) - \\sin(k\\omega_\\ell)]/(\\pi k)$, y $\\omega_{\\ell,h} = 2\\pi/p_{u,\\ell}$. En esta estimaci\\''{o}n se utiliz\\''{o} $p_\\ell = %d$ y $p_u = %d$ trimestres.\n\n', params.cf_pl, params.cf_pu);
w('');

w('\subsection{Modelo Markov Switching MS-MH(3)}');
w('');
w(['El ciclo extra\''ido, $c_t$, se modela como un proceso cuya distribuci\''on ' ...
   'condicional cambia seg\''un un estado no observable $s_t \in \{1,2,3\}$:']);
w('');
w('\begin{equation}');
w('  c_t = \mu_{s_t} + \sigma_{s_t}\,\varepsilon_t, \qquad \varepsilon_t \overset{iid}{\sim} \mathcal{N}(0,1)');
w('\end{equation}');
w('');
w(['La variable de estado $s_t$ sigue una cadena de Markov de primer orden con ' ...
   'matriz de transici\''on $\mathbf{P} = [p_{ij}]$, donde ' ...
   '$p_{ij} = P(s_t = j \mid s_{t-1} = i)$, con $\sum_j p_{ij} = 1$.']);
w('');
w('\subsection{Estimaci\''on: Algoritmo EM}');
w('');
w(['\textbf{Paso E (filtro de Hamilton, adelante):} En cada periodo $t$ se calcula ' ...
   'la probabilidad filtrada $P(s_t = k \mid \Omega_t)$ mediante la actualizaci\''on ' ...
   'bayesiana sobre la densidad normal por estado:']);
w('\begin{equation}');
w('  P(s_t{=}k \mid \Omega_t) = \frac{P(s_t{=}k \mid \Omega_{t-1})\,\phi(c_t;\mu_k,\sigma_k)}');
w('    {\sum_{j=1}^{3} P(s_t{=}j \mid \Omega_{t-1})\,\phi(c_t;\mu_j,\sigma_j)}');
w('\end{equation}');
w('');
w(['\textbf{Paso E (suavizador de Kim, atr\''as):} Usando toda la muestra $\Omega_T$, ' ...
   'se obtiene la probabilidad suavizada $P(s_t = k \mid \Omega_T)$ mediante la ' ...
   'recurrencia hacia atr\''as de \citet{Kim1994}:']);
w('\begin{equation}');
w('  P(s_t{=}j \mid \Omega_T) = \sum_{k=1}^{3}');
w('  \frac{P(s_{t+1}{=}k \mid \Omega_T)\,p_{jk}\,P(s_t{=}j \mid \Omega_t)}');
w('       {P(s_{t+1}{=}k \mid \Omega_t)}');
w('\end{equation}');
w('');
w(['\textbf{Paso M:} Los par\''ametros $\{\mu_k, \sigma_k, p_{ij}\}$ se actualizan ' ...
   'en forma cerrada usando las probabilidades suavizadas como ponderaciones. ' ...
   'El proceso se itera hasta convergencia en la log-verosimilitud.']);
w('');

% =========================================================================
% SECCION 2: RESULTADOS
% =========================================================================
w('\newpage');
w('\section{Resultados}');
w('');

% --- Estadisticas del ciclo ---
w('\subsection{Estad\''isticas Descriptivas del Ciclo CF}');
w('');
w('\begin{table}[H]');
w('  \centering');
w('  \caption{Estad\''isticas del ciclo CF asim\''etrico}');
w('  \begin{tabular}{lc}');
w('    \toprule');
w('    Estad\''istica & Valor \\\\');
w('    \midrule');
fprintf(fid, '    Observaciones        & %d \\\\\n', res.cy_nobs);
fprintf(fid, '    Per\\''iodo            & %s -- %s \\\\\n', first_date_str, last_date_str);
fprintf(fid, '    Media               & %.4f \\\\\n', res.cy_mean);
fprintf(fid, '    Desviaci\\''on est\\''andar & %.4f \\\\\n', res.cy_sd);
fprintf(fid, '    Umbral recesi\\''on (p33) & %.4f \\\\\n', res.umbral_rec);
fprintf(fid, '    Umbral auge   (p67) & %.4f \\\\\n', res.umbral_auge);
fprintf(fid, '    \\''Ultimo valor observado ($c_T$) & %.4f \\\\\n', res.cy_last);
w('    \bottomrule');
w('  \end{tabular}');
w('\end{table}');
w('');

% --- Parametros del MS ---
w('\subsection{Par\''ametros Estimados del Modelo MS-MH(3)}');
w('');
w('\begin{table}[H]');
w('  \centering');
w('  \caption{Par\''ametros por r\''egimen --- Modelo MS-MH(3)}');
w('  \begin{tabular}{lccccc}');
w('    \toprule');
w('    R\''egimen & $\hat{\mu}_k$ & $\hat{\sigma}_k$ & $\hat{p}_{kk}$ & Dur. esperada & $N$ periodos \\\\');
w('    \midrule');
fprintf(fid, '    Recesi\\''on  & %.4f & %.4f & %.4f & %.1f trim. & %d \\\\\n', ...
    ms.mu_rec,  ms.sigma_rec,  ms.p_rr, ms.dur_rec,  ms.n_rec);
fprintf(fid, '    Expansi\\''on & %.4f & %.4f & %.4f & %.1f trim. & %d \\\\\n', ...
    ms.mu_exp,  ms.sigma_exp,  ms.p_ee, ms.dur_exp,  ms.n_exp);
fprintf(fid, '    Auge        & %.4f & %.4f & %.4f & %.1f trim. & %d \\\\\n', ...
    ms.mu_auge, ms.sigma_auge, ms.p_aa, ms.dur_auge, ms.n_auge);
w('    \bottomrule');
w('  \end{tabular}');
w('  \label{tab:params}');
w('\end{table}');
w('');

% --- Matriz de transicion ---
w('\subsection{Matriz de Transici\''on Estimada}');
w('');
w('\begin{table}[H]');
w('  \centering');
w('  \caption{Matriz de transici\''on $\hat{\mathbf{P}} = [\hat{p}_{ij}]$}');
w('  \begin{tabular}{lccc}');
w('    \toprule');
w('    $s_{t-1} \backslash s_t$ & Recesi\''on & Expansi\''on & Auge \\\\');
w('    \midrule');
fprintf(fid, '    Recesi\\''on  & %.4f & %.4f & %.4f \\\\\n', ms.p_rr, ms.p_re, ms.p_ra);
fprintf(fid, '    Expansi\\''on & %.4f & %.4f & %.4f \\\\\n', ms.p_er, ms.p_ee, ms.p_ea);
fprintf(fid, '    Auge        & %.4f & %.4f & %.4f \\\\\n', ms.p_ar, ms.p_ae, ms.p_aa);
w('    \bottomrule');
w('  \end{tabular}');
w('  \label{tab:trans}');
w('\end{table}');
w('');

% --- Ajuste del modelo ---
w('\subsection{Bondad de Ajuste}');
w('');
w('\begin{table}[H]');
w('  \centering');
w('  \caption{Criterios de informaci\''on y ajuste del modelo MS-MH(3)}');
w('  \begin{tabular}{lc}');
w('    \toprule');
w('    Criterio & Valor \\\\');
w('    \midrule');
fprintf(fid, '    Log-verosimilitud ($\\hat{\\ell}$) & %.4f \\\\\n', ms.loglik);
fprintf(fid, '    AIC                              & %.4f \\\\\n', ms.aic);
fprintf(fid, '    BIC                              & %.4f \\\\\n', ms.bic);
fprintf(fid, '    Par\\''ametros libres              & %d \\\\\n',  ms.n_params);
fprintf(fid, '    Convergencia                     & %s \\\\\n',   strrep(ms.converged_str,'_','\_'));
fprintf(fid, '    Iteraciones                      & %d \\\\\n',   ms.n_iter);
w('    \bottomrule');
w('  \end{tabular}');
w('\end{table}');
w('');

% --- Probabilidades ultimo periodo ---
w('\subsection{Probabilidades del \''{U}ltimo Per\''iodo}');
w('');
w('\begin{table}[H]');
w('  \centering');
fprintf(fid, '  \\caption{Probabilidades suavizadas --- Per\\''iodo: %s}\n', last_date_str);
w('  \begin{tabular}{lcc}');
w('    \toprule');
w('    R\''egimen & $P(s_T = k \mid \Omega_T)$ & Interpretaci\''on \\\\');
w('    \midrule');
fprintf(fid, '    Recesi\\''on  & %.2f\\%% & Brecha del producto negativa ($c_T < %.4f$) \\\\\n', 100*res.pms_rec,  res.umbral_rec);
fprintf(fid, '    Expansi\\''on & %.2f\\%% & Brecha del producto moderada \\\\\n',                100*res.pms_exp);
fprintf(fid, '    Auge        & %.2f\\%% & Brecha del producto positiva ($c_T > %.4f$) \\\\\n',  100*res.pms_auge, res.umbral_auge);
fprintf(fid, '    \\midrule\n    Total & 100.00\\%% & \\\\\n');
w('    \bottomrule');
w('  \end{tabular}');
w('\end{table}');
w('');

% =========================================================================
% SECCION 3: FIGURAS
% =========================================================================
w('\newpage');
w('\section{An\''alisis Gr\''afico}');
w('');

% Fig 1
w('\begin{figure}[H]');
w('  \centering');
fprintf(fid, '  \\includegraphics[width=\\textwidth]{%s/fig1_gdp_cycle.pdf}\n', fig_rel);
w('  \caption{PIB real (logaritmo) y ciclo CF asim\''etrico con sombreado de reg\''imenes.}');
w('  \label{fig:gdp_cycle}');
w('\end{figure}');
w('');

% Fig 2
w('\begin{figure}[H]');
w('  \centering');
fprintf(fid, '  \\includegraphics[width=\\textwidth]{%s/fig2_smoothed_probs.pdf}\n', fig_rel);
w('  \caption{Probabilidades suavizadas $P(s_t = k \mid \Omega_T)$ para los tres reg\''imenes.}');
w('  \label{fig:probs}');
w('\end{figure}');
w('');

% Fig 3 y 4 lado a lado
w('\begin{figure}[H]');
w('  \centering');
w('  \begin{subfigure}[b]{0.48\textwidth}');
fprintf(fid, '    \\includegraphics[width=\\textwidth]{%s/fig3_transition_matrix.pdf}\n', fig_rel);
w('    \caption{Matriz de transici\''on estimada.}');
w('  \end{subfigure}');
w('  \hfill');
w('  \begin{subfigure}[b]{0.48\textwidth}');
fprintf(fid, '    \\includegraphics[width=\\textwidth]{%s/fig4_regime_classification.pdf}\n', fig_rel);
w('    \caption{Clasificaci\''on discreta de reg\''imenes.}');
w('  \end{subfigure}');
w('  \caption{Matriz de transici\''on (izq.) y clasificaci\''on hist\''orica (der.).}');
w('  \label{fig:trans_class}');
w('\end{figure}');
w('');

% =========================================================================
% SECCION 4: INTERPRETACION
% =========================================================================
w('\section{Interpretaci\''on Econ\''omica}');
w('');

% CORRECCION Bug 4: extraer probabilidad del regimen dominante directamente
[~, reg_dom] = max([res.pms_rec, res.pms_exp, res.pms_auge]);
etiq      = {'recesivo','expansivo','de auge'};
probs_vec = [res.pms_rec, res.pms_exp, res.pms_auge];
prob_dom  = 100 * probs_vec(reg_dom);   % escalar correcto

if res.cy_last < res.umbral_rec
    pos_str = 'por debajo de';
elseif res.cy_last > res.umbral_auge
    pos_str = 'por encima de';
else
    pos_str = 'entre';
end

fprintf(fid, ['El ciclo del PIB se encuentra actualmente en un r\\''egimen predominantemente ' ...
    '\\textbf{%s}, con una probabilidad suavizada del %.1f\\%% al cierre del per\\''iodo %s. ' ...
    'El valor del ciclo CF es $c_T = %.4f$, que se sit\\''ua %s los umbrales de ' ...
    'referencia (recesi\\''on: $%.4f$; auge: $%.4f$).\n\n'], ...
    etiq{reg_dom}, prob_dom, last_date_str, res.cy_last, ...
    pos_str, res.umbral_rec, res.umbral_auge);

fprintf(fid, ['La duraci\\''on esperada del r\\''egimen de recesi\\''on es de %.1f trimestres ' ...
    '(probabilidad de persistencia $\\hat{p}_{11} = %.3f$), mientras que la expansi\\''on ' ...
    'tiene una duraci\\''on esperada de %.1f trimestres ($\\hat{p}_{22} = %.3f$) ' ...
    'y el auge de %.1f trimestres ($\\hat{p}_{33} = %.3f$).\n'], ...
    ms.dur_rec, ms.p_rr, ms.dur_exp, ms.p_ee, ms.dur_auge, ms.p_aa);
w('');

% =========================================================================
% REFERENCIAS
% =========================================================================
w('\newpage');
w('\section*{Referencias}');
w('\addcontentsline{toc}{section}{Referencias}');
w('');
w('\begin{thebibliography}{99}');
w('');
w('\bibitem{Hamilton1989}');
w('  Hamilton, J.D. (1989).\\');
w('  \textit{A New Approach to the Economic Analysis of Nonstationary Time Series and the Business Cycle.}\\');
w('  \textit{Econometrica}, 57(2), 357--384.');
w('');
w('\bibitem{KimNelson1999}');
w('  Kim, C.J. \& Nelson, C.R. (1999).\\');
w('  \textit{State-Space Models with Regime Switching: Classical and Gibbs-Sampling Approaches with Applications.}\\');
w('  MIT Press, Cambridge.');
w('');
w('\bibitem{Kim1994}');
w('  Kim, C.J. (1994).\\');
w('  Dynamic linear models with Markov-switching.\\');
w('  \textit{Journal of Econometrics}, 60(1--2), 1--22.');
w('');
w('\bibitem{CF2003}');
w('  Christiano, L.J. \& Fitzgerald, T.J. (2003).\\');
w('  The Band Pass Filter.\\');
w('  \textit{International Economic Review}, 44(2), 435--465.');
w('');
w('\bibitem{Krolzig1997}');
w('  Krolzig, H.M. (1997).\\');
w('  \textit{Markov-Switching Vector Autoregressions.}\\');
w('  Springer, Berlin.');
w('');
w('\end{thebibliography}');
w('');
w('\end{document}');

fclose(fid);
fprintf('      LaTeX generado: %s\n', tex_file);
end
