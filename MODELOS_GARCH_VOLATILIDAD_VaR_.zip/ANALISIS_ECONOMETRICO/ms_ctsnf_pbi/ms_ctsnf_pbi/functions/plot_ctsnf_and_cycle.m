function fig = plot_ctsnf_and_cycle(dates, gdp_log, cycle, ms_result)
% PLOT_CTSNF_AND_CYCLE  Panel de 2 graficos: CTSNF (log) y ciclo CF con sombreado de regimenes
%
% CORRECCIONES v1.2 -> v1.3:
%   - Eliminadas subfunciones locales plot_smoothed_probs, plot_transition_matrix
%     y plot_regime_classification que estaban duplicadas dentro de este archivo.
%     MATLAB no permite dos funciones locales con el mismo nombre en el mismo
%     archivo. Ahora cada funcion reside unicamente en su propio archivo .m.

fig = figure('Units','centimeters','Position',[2 2 22 16],'Color','w');

% Colores por regimen
col_rec  = [0.85 0.20 0.20];   % rojo
col_auge = [0.18 0.55 0.18];   % verde

% --- Panel superior: log CTSNF ---
ax1 = subplot(2,1,1);
plot(dates, gdp_log, 'Color',[0.15 0.35 0.65],'LineWidth',1.6);
hold on;

shade_regime(dates, ms_result.sp_rec,  0.5, col_rec,  0.20);
shade_regime(dates, ms_result.sp_auge, 0.5, col_auge, 0.15);

ylabel('Log CTSNF Real','FontSize',10);
title('CTSNF Real (logaritmo) con periodos de regimen identificados','FontSize',11);
set(ax1,'FontSize',9,'XGrid','on','YGrid','on','GridAlpha',0.3);
datetick('x','yyyy','keeplimits');
legend({'Log CTSNF','Recesion (P>0.5)','Auge (P>0.5)'},'Location','northwest','FontSize',8);

% --- Panel inferior: ciclo CF ---
ax2 = subplot(2,1,2);
fill([dates; flipud(dates)], [cycle; zeros(size(cycle))], ...
     [0.75 0.85 0.95],'EdgeColor','none','FaceAlpha',0.5);
hold on;
plot(dates, cycle, 'Color',[0.15 0.35 0.65],'LineWidth',1.5);
plot(dates([1 end]), [0 0], 'k-','LineWidth',0.8);
shade_regime(dates, ms_result.sp_rec,  0.5, col_rec,  0.18);
shade_regime(dates, ms_result.sp_auge, 0.5, col_auge, 0.13);

ylabel('Ciclo CF Asimetrico','FontSize',10);
xlabel('Periodo','FontSize',10);
title('Componente ciclico extraido por filtro Christiano-Fitzgerald (2003)','FontSize',11);
set(ax2,'FontSize',9,'XGrid','on','YGrid','on','GridAlpha',0.3);
datetick('x','yyyy','keeplimits');

set(fig,'PaperPositionMode','auto');
end

% =========================================================================
% FUNCIONES AUXILIARES LOCALES (exclusivamente de graficacion)
% =========================================================================

function shade_regime(dates, prob, threshold, color, alpha)
% Sombrea en un eje los periodos donde prob > threshold
idx = find(prob > threshold);
if isempty(idx), return; end

yl = ylim();
for ii = 1:length(idx)
    t = idx(ii);
    if t == 1
        x1 = dates(1);
    else
        x1 = dates(t-1);
    end
    if t == length(dates)
        x2 = dates(end);
    else
        x2 = dates(t+1);
    end
    fill([x1 x2 x2 x1], [yl(1) yl(1) yl(2) yl(2)], color, ...
         'EdgeColor','none','FaceAlpha',alpha,'HandleVisibility','off');
    hold on;
end
end
