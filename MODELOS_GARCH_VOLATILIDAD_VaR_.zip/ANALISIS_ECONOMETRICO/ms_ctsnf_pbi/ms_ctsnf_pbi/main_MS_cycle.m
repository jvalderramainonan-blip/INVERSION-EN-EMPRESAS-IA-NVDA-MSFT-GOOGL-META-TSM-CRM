% =========================================================================
% MAIN_MS_CYCLE.M
% Ciclo del PIB por Filtro CF Asimetrico + Markov Switching de 3 Estados
%
% PIPELINE:
%   1. Carga de datos (GDP real, FRED o CSV local)
%   2. Transformacion: log-niveles -> tasas de crecimiento (100*dlog)
%   3. Extraccion del ciclo por filtro Christiano-Fitzgerald asimetrico
%   4. Estandarizacion del ciclo (media=0, sd=1) para estimacion numerica
%   5. Estimacion del modelo Markov Switching MS-MH(3)
%   6. Identificacion de regimenes por media estimada
%   7. Calculo de probabilidades suavizadas (Kim smoother)
%   8. Generacion de tablas y figuras
%   9. Exportacion de resultados a LaTeX -> PDF
%
% NOTA METODOLOGICA (v1.4):
%   El filtro CF opera sobre la TASA DE CRECIMIENTO del PIB (100*dlog),
%   no sobre el nivel en logaritmos. Esto elimina la tendencia estocastica
%   I(1) antes del filtrado, conforme a Christiano & Fitzgerald (2003) y
%   Hamilton (1989). El ciclo resultante tiene escala en puntos porcentuales
%   (aproximadamente +-2% para EE.UU.), lo que permite una estimacion MS
%   numericamente estable. El modelo MS estima sobre el ciclo estandarizado
%   (z-score), y los umbrales se reportan en las unidades originales del ciclo.
%
% REFERENCIAS:
%   Hamilton (1989) Econometrica 57(2):357-384
%   Kim & Nelson (1999) State-Space Models. MIT Press.
%   Christiano & Fitzgerald (2003) Int'l Econ. Review 44(2):435-465
%   Krolzig (1997) Markov-Switching VAR. Springer.
%
% REQUISITOS: MATLAB R2019b+ (Statistics and Machine Learning Toolbox)
%             pdflatex disponible en PATH para compilar el reporte
%
% AUTOR: Joan Valderrama Inonan  |  UNAC - Macroeconometria
% VERSION: 1.4  |  JUNIO 2026
% =========================================================================

clear; clc; close all;
addpath('functions');

fprintf('=============================================================\n');
fprintf('  CICLO CF ASIMETRICO + MARKOV SWITCHING MS-MH(3)\n');
fprintf('  Hamilton (1989) / Kim & Nelson (1999)\n');
fprintf('  VERSION 1.4 — Transformacion correcta del ciclo\n');
fprintf('=============================================================\n\n');

% -------------------------------------------------------------------------
% 1. PARAMETROS GLOBALES
% -------------------------------------------------------------------------
params.states      = 3;          % numero de regimenes
params.cf_pl       = 6;          % CF: periodo minimo del ciclo (trimestres)
params.cf_pu       = 32;         % CF: periodo maximo del ciclo (trimestres)
params.cf_drift    = true;       % CF: ajuste de extremos I(1) con drift
params.maxiter     = 2000;       % EM: iteraciones maximas
params.tol         = 1e-8;       % EM: tolerancia de convergencia (mas estricta)
params.n_restarts  = 15;         % EM: numero de reinicios (mas reinicios = mejor optimo global)
params.quantile_lo = 0.25;       % Umbral recesion (percentil 25 — mas conservador)
params.quantile_hi = 0.75;       % Umbral auge    (percentil 75)
params.seed        = 42;         % Semilla aleatoria (reproducibilidad)
params.output_dir  = 'output_pbi';   % Directorio de salida de figuras
params.latex_dir   = 'latex_pbi';    % Directorio del reporte LaTeX

rng(params.seed);

% -------------------------------------------------------------------------
% 2. CARGA DE DATOS
% -------------------------------------------------------------------------
fprintf('[1/7] Cargando datos...\n');

csv_path = fullfile('data', 'gdp_usa.csv');
if exist(csv_path, 'file')
    [dates_raw, gdp_log] = load_gdp_csv(csv_path);
    fprintf('      Datos cargados desde: %s\n', csv_path);
else
    fprintf('      CSV no encontrado. Generando serie sintetica de ejemplo.\n');
    [dates_raw, gdp_log] = generate_synthetic_gdp(180);
end

% Diagnostico de escala del log-PIB
fprintf('      Log-PIB: min=%.3f  max=%.3f  (esperado 7-10 para FRED GDPC1)\n', ...
        min(gdp_log), max(gdp_log));
if max(gdp_log) - min(gdp_log) > 5
    warning('SCALE: El rango del log-PIB (%.2f) es inusualmente grande. Verifique la serie.', ...
            max(gdp_log) - min(gdp_log));
end

fprintf('      Observaciones (niveles): %d\n', length(gdp_log));
fprintf('      Periodo (niveles): %s  a  %s\n', datenum2qstr(dates_raw(1)), ...
        datenum2qstr(dates_raw(end)));

% -------------------------------------------------------------------------
% 3. TRANSFORMACION: TASA DE CRECIMIENTO DEL PIB
% -------------------------------------------------------------------------
% El filtro CF requiere una serie estacionaria (o al menos sin tendencia
% determinista fuerte). La practica estandar es usar la primera diferencia
% del logaritmo, que aproxima la tasa de crecimiento trimestral del PIB:
%   g_t = 100 * (log(PIB_t) - log(PIB_{t-1}))
% Esta transformacion elimina la tendencia I(1) y produce una serie
% con media cercana a 0.5-0.8% trimestral para EE.UU. (Hamilton 1989).
%
% Alternativa: si se desea trabajar con el nivel del log-PIB y el filtro CF
% extrae el ciclo de tendencia, establecer USE_GROWTH_RATE = false.
% En ese caso el ciclo sera de mayor amplitud y requerira estandarizacion.

USE_GROWTH_RATE = true;   % true = tasas de crecimiento (recomendado)
                           % false = nivel del log-PIB (experimental)

if USE_GROWTH_RATE
    % Primera diferencia logaritmica (se pierde una observacion)
    gdp_growth = 100 * diff(gdp_log);   % tasa de crecimiento trimestral (%)
    dates      = dates_raw(2:end);       % alinear fechas
    T_full     = length(gdp_growth);

    fprintf('\n[1b] Transformacion a tasas de crecimiento:\n');
    fprintf('      Observaciones (crecimientos): %d\n', T_full);
    fprintf('      Media=%.4f%%  SD=%.4f%%  (esperado: media~0.8, sd~0.9 para EE.UU.)\n', ...
            mean(gdp_growth), std(gdp_growth));

    % Verificacion de escala — alerta si la media o sd son anormales
    if abs(mean(gdp_growth)) > 5 || std(gdp_growth) > 10
        warning('SCALE: Las tasas de crecimiento tienen escala inusual. Verifique la unidad del PIB en el CSV.');
    end

    series_for_cf = gdp_growth;   % serie a filtrar
else
    gdp_growth    = gdp_log;
    dates         = dates_raw;
    T_full        = length(gdp_log);
    series_for_cf = gdp_log;
    fprintf('\n      [MODO NIVEL] Se usara el log-PIB directamente.\n');
end

% -------------------------------------------------------------------------
% 4. FILTRO CHRISTIANO-FITZGERALD ASIMETRICO
% -------------------------------------------------------------------------
fprintf('\n[2/7] Aplicando filtro CF asimetrico...\n');

cycle_raw = cf_filter_asymmetric(series_for_cf, params.cf_pl, params.cf_pu, params.cf_drift);

% Diagnostico critico de escala del ciclo
fprintf('      Ciclo (sin estandarizar): media=%.4f  sd=%.4f  min=%.4f  max=%.4f\n', ...
        mean(cycle_raw), std(cycle_raw), min(cycle_raw), max(cycle_raw));

% ESTANDARIZACION DEL CICLO (z-score)
% Razon: el algoritmo EM es numericamente sensible a la escala. Un ciclo con
% sd=1.18 (como ocurre con el nivel del log-PIB) produce densidades normales
% muy concentradas en un regimen y colapsa las probabilidades a 0/1.
% La estandarizacion normaliza la escala para el EM; los parametros mu y sigma
% estimados se reportan en unidades del z-score, y los umbrales se convierten
% de vuelta a unidades del ciclo original al final.
cycle_mean_raw = mean(cycle_raw);
cycle_sd_raw   = std(cycle_raw);
cycle          = (cycle_raw - cycle_mean_raw) / cycle_sd_raw;   % z-score

fprintf('      Ciclo (estandarizado): media=%.4f  sd=%.4f  (por construccion ~0 y ~1)\n', ...
        mean(cycle), std(cycle));

T = length(cycle);

% Umbrales en unidades del ciclo ORIGINAL (para interpretacion economica)
umbral_rec  = quantile(cycle_raw, params.quantile_lo);
umbral_auge = quantile(cycle_raw, params.quantile_hi);
cy_mean     = cycle_mean_raw;
cy_sd       = cycle_sd_raw;
cy_nobs     = sum(~isnan(cycle));
cy_last_raw = cycle_raw(end);   % valor del ultimo periodo en unidades originales

fprintf('      Umbral recesion (p%.0f): %.4f%%\n', 100*params.quantile_lo, umbral_rec);
fprintf('      Umbral auge     (p%.0f): %.4f%%\n', 100*params.quantile_hi, umbral_auge);
fprintf('      Ultimo valor del ciclo:  %.4f%%\n', cy_last_raw);

% -------------------------------------------------------------------------
% 5. ESTIMACION MARKOV SWITCHING MS-MH(3)
% -------------------------------------------------------------------------
fprintf('\n[3/7] Estimando modelo MS-MH(3)...\n');
fprintf('      Hamilton filter + Kim smoother\n');
fprintf('      Reinicios: %d  |  MaxIter: %d  |  Tol: %.1e\n', ...
        params.n_restarts, params.maxiter, params.tol);

ms_result = estimate_markov_switching(cycle, params);

fprintf('      Log-Verosimilitud: %.4f\n', ms_result.loglik);
fprintf('      AIC: %.4f   BIC: %.4f\n', ms_result.aic, ms_result.bic);
fprintf('      Convergencia: %s  (iter=%d)\n', ...
        ms_result.converged_str, ms_result.n_iter);

% -------------------------------------------------------------------------
% 6. IDENTIFICACION DE REGIMENES (por media estimada)
% -------------------------------------------------------------------------
fprintf('\n[4/7] Identificando regimenes por media estimada...\n');

ms_result = identify_regimes(ms_result);

% Reconvertir mu y sigma a unidades originales del ciclo para reporte
mu_rec_orig   = ms_result.mu_rec   * cycle_sd_raw + cycle_mean_raw;
mu_exp_orig   = ms_result.mu_exp   * cycle_sd_raw + cycle_mean_raw;
mu_auge_orig  = ms_result.mu_auge  * cycle_sd_raw + cycle_mean_raw;
sig_rec_orig  = ms_result.sigma_rec  * cycle_sd_raw;
sig_exp_orig  = ms_result.sigma_exp  * cycle_sd_raw;
sig_auge_orig = ms_result.sigma_auge * cycle_sd_raw;

fprintf('      Regimen 1 (Recesion):  mu=%.4f%%  sigma=%.4f%%\n', mu_rec_orig,  sig_rec_orig);
fprintf('      Regimen 2 (Expansion): mu=%.4f%%  sigma=%.4f%%\n', mu_exp_orig,  sig_exp_orig);
fprintf('      Regimen 3 (Auge):      mu=%.4f%%  sigma=%.4f%%\n', mu_auge_orig, sig_auge_orig);

% Duraciones esperadas
D = 1 ./ (1 - diag(ms_result.P_trans));
fprintf('      Duracion esperada: Rec=%.1f  Exp=%.1f  Auge=%.1f trimestres\n', D(1), D(2), D(3));

% Probabilidades del ultimo periodo
pms_rec  = ms_result.sp_rec(end);
pms_exp  = ms_result.sp_exp(end);
pms_auge = ms_result.sp_auge(end);

fprintf('      Probabilidades (ultimo periodo: %s):\n', datenum2qstr(dates(end)));
fprintf('        P(Recesion)  = %.2f%%\n', 100*pms_rec);
fprintf('        P(Expansion) = %.2f%%\n', 100*pms_exp);
fprintf('        P(Auge)      = %.2f%%\n', 100*pms_auge);

% -------------------------------------------------------------------------
% 7. FIGURAS
% -------------------------------------------------------------------------
fprintf('\n[5/7] Generando figuras...\n');

if ~exist(params.output_dir, 'dir'), mkdir(params.output_dir); end

% Usar ciclo_raw para graficos (unidades interpretables)
ms_result_plot       = ms_result;
ms_result_plot.cycle = cycle_raw;   % para que las figuras muestren unidades %

fig1 = plot_gdp_and_cycle(dates, gdp_growth, cycle_raw, ms_result);
saveas(fig1, fullfile(params.output_dir, 'fig1_gdp_cycle.pdf'));

fig2 = plot_smoothed_probs(dates, ms_result);
saveas(fig2, fullfile(params.output_dir, 'fig2_smoothed_probs.pdf'));

fig3 = plot_transition_matrix(ms_result);
saveas(fig3, fullfile(params.output_dir, 'fig3_transition_matrix.pdf'));

fig4 = plot_regime_classification(dates, cycle_raw, ms_result);
saveas(fig4, fullfile(params.output_dir, 'fig4_regime_classification.pdf'));

fprintf('      Figuras guardadas en: %s/\n', params.output_dir);

% -------------------------------------------------------------------------
% 8. REPORTE LATEX (solo .tex, sin compilacion a PDF)
% -------------------------------------------------------------------------
fprintf('\n[6/7] Generando reporte LaTeX...\n');

results_struct = struct();
results_struct.dates       = dates;
results_struct.gdp_log     = gdp_growth;   % serie filtrada (tasas de crecimiento)
results_struct.cycle       = cycle_raw;    % ciclo en unidades originales
results_struct.ms          = ms_result;
results_struct.cy_mean     = cy_mean;
results_struct.cy_sd       = cy_sd;
results_struct.cy_nobs     = cy_nobs;
results_struct.cy_last     = cy_last_raw;
results_struct.umbral_rec  = umbral_rec;
results_struct.umbral_auge = umbral_auge;
results_struct.pms_rec     = pms_rec;
results_struct.pms_exp     = pms_exp;
results_struct.pms_auge    = pms_auge;
results_struct.D_durations = D;
results_struct.params      = params;
% Parametros en unidades originales para el reporte
results_struct.mu_rec_orig   = mu_rec_orig;
results_struct.mu_exp_orig   = mu_exp_orig;
results_struct.mu_auge_orig  = mu_auge_orig;
results_struct.sig_rec_orig  = sig_rec_orig;
results_struct.sig_exp_orig  = sig_exp_orig;
results_struct.sig_auge_orig = sig_auge_orig;

generate_latex_report(results_struct, params);

tex_file = fullfile(params.latex_dir, 'reporte_MS_ciclo.tex');
fprintf('\n[7/7] Reporte LaTeX generado en: %s\n', tex_file);

fprintf('\n=============================================================\n');
fprintf('  ESTIMACION COMPLETADA\n');
fprintf('  Periodo: %s  a  %s\n', datenum2qstr(dates(1)), datenum2qstr(dates(end)));
fprintf('  Ciclo ultimo periodo: %.4f%%\n', cy_last_raw);
fprintf('  P(Recesion)  = %.2f%%\n', 100*pms_rec);
fprintf('  P(Expansion) = %.2f%%\n', 100*pms_exp);
fprintf('  P(Auge)      = %.2f%%\n', 100*pms_auge);
fprintf('=============================================================\n');
