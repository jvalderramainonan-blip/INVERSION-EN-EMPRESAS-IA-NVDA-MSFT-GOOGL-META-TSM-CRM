# Adaptación CTSNF Real

Este paquete fue adaptado desde el script original de Markov Switching para usar la hoja 3 del Excel:
`SERIE_CREDITOS_SECTOR_NO_FINANCIERO.xlsx`

## Flujo
1. Ejecutar `data/convert_ctsnf_xlsx.m` para generar `data/ctsnf_real.csv`.
2. Ejecutar `main_MS_cycle_CTSNF.m`.
3. El resto del pipeline se mantiene:
   - log-diferencias trimestrales
   - filtro Christiano-Fitzgerald asimétrico
   - estandarización
   - estimación Markov Switching MS-MH(3)
   - suavizado Kim
   - reporte y figuras

## Archivo principal
- `main_MS_cycle_CTSNF.m`
