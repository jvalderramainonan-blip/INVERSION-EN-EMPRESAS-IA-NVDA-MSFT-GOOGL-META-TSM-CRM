# MS_PROBIT_MATLAB — Paquete Markov Switching MS-MH(3)
## Ciclo del PIB por Filtro CF Asimétrico + Estimación de Probabilidades de Régimen

**Autor:** Joan Valderrama Inonan | UNAC — Macroeconometría  
**Versión:** 1.1 | Junio 2026  
**MATLAB:** R2019b o superior (Statistics and Machine Learning Toolbox)

---

## Datos incluidos: FRED GDPC1

Este paquete incluye la serie oficial **GDPC1 — Real Gross Domestic Product** descargada del Federal Reserve Economic Data (FRED), Federal Reserve Bank of St. Louis.

| Campo         | Detalle                                                        |
|---------------|----------------------------------------------------------------|
| Serie         | GDPC1                                                          |
| Descripción   | PIB real de EE.UU., miles de millones de USD (base 2017), SAAR |
| Frecuencia    | Trimestral                                                     |
| Cobertura     | 1947-Q1 – 2026-Q1  (317 observaciones)                        |
| Última act.   | 2026-05-28                                                     |
| Fuente        | https://fred.stlouisfed.org/series/GDPC1                       |
| Archivo local | `data/gdp_usa.csv`                                             |

> El script `main_MS_cycle.m` detecta automáticamente `data/gdp_usa.csv` y lo usa
> como fuente de datos principal, sin necesidad de configuración adicional.

---

## Estructura del paquete

```
ms_probit_matlab/
├── main_MS_cycle.m                  ← Script principal (punto de entrada)
├── README.md                        ← Este archivo
├── data/
│   ├── gdp_usa.csv                  ← GDPC1 (FRED, 1947-Q1 a 2026-Q1) ✓
│   ├── GDPC1.xlsx                   ← Archivo original de FRED
│   ├── COLOQUE_DATOS_AQUI.txt       ← Instrucciones para actualizar datos
│   └── convert_gdpc1_xlsx.m         ← Convierte GDPC1.xlsx → gdp_usa.csv
├── functions/
│   ├── cf_filter_asymmetric.m       Filtro Christiano-Fitzgerald asimétrico
│   ├── estimate_markov_switching.m  Estimación MS-MH(K) por algoritmo EM
│   ├── identify_regimes.m           Identificación de regímenes por media
│   ├── plot_gdp_and_cycle.m         Figura 1: PIB y ciclo
│   ├── plot_smoothed_probs.m        Figura 2: Probabilidades suavizadas
│   ├── plot_transition_matrix.m     Figura 3: Heatmap de transición
│   ├── plot_regime_classification.m Figura 4: Clasificación histórica
│   ├── load_gdp_csv.m               Carga de datos desde CSV
│   ├── generate_synthetic_gdp.m     Datos sintéticos de demostración
│   ├── generate_latex_report.m      Generador del reporte LaTeX
│   └── compile_latex.m              Compilador pdflatex → PDF
├── output/                          ← (Generado automáticamente) Figuras .pdf
└── latex/                           ← (Generado automáticamente) Reporte .tex / .pdf
```

---

## Ejecución rápida

**Paso 1.** Abrir MATLAB y navegar a la carpeta raíz del paquete:
```matlab
cd('ruta/a/ms_probit_matlab')
```

**Paso 2.** Ejecutar el script principal:
```matlab
main_MS_cycle
```

El script detecta automáticamente `data/gdp_usa.csv` (GDPC1, 1947–2026) y ejecuta
el pipeline completo. No se requiere configuración adicional.

---

## Actualización de datos

Para incorporar observaciones más recientes del PIB:

**Opción A — Método automático (MATLAB):**
```matlab
% Descargue GDPC1.xlsx desde FRED y colóquelo en data/
% Luego ejecute:
run('data/convert_gdpc1_xlsx.m')
```

**Opción B — Manual:**
Edite `data/gdp_usa.csv` agregando filas al final en el formato:
```
2026-Q2,24XXX.XXX
```

---

## Uso con datos propios

Si desea usar un PIB diferente (otro país, otra fuente), reemplace `data/gdp_usa.csv`
manteniendo el formato:

```
date,gdp_real
1947-Q1,2182.681
1947-Q2,2176.892
...
```

La primera columna acepta los formatos `YYYY-QN`, `YYYY-MM-DD` o `YYYYMMDD`.
La segunda columna debe contener el nivel del PIB real (no logaritmo).
El script aplica `log()` internamente.

---

## Parámetros configurables

En el bloque de `params` al inicio de `main_MS_cycle.m`:

| Parámetro       | Valor por defecto | Descripción                                    |
|-----------------|:-----------------:|------------------------------------------------|
| `states`        | 3                 | Número de regímenes K del modelo MS            |
| `cf_pl`         | 6                 | Período mínimo del ciclo CF (trimestres)       |
| `cf_pu`         | 32                | Período máximo del ciclo CF (trimestres)       |
| `cf_drift`      | true              | Filtro CF asimétrico (acomoda I(1) con drift)  |
| `maxiter`       | 2000              | Iteraciones máximas del algoritmo EM           |
| `tol`           | 1e-7              | Tolerancia de convergencia (log-verosimilitud) |
| `n_restarts`    | 10                | Reinicios aleatorios del EM                    |
| `quantile_lo`   | 0.33              | Percentil para umbral de recesión              |
| `quantile_hi`   | 0.67              | Percentil para umbral de auge                  |
| `seed`          | 42                | Semilla para reproducibilidad                  |

---

## Generación del reporte PDF

El reporte PDF requiere una instalación de LaTeX en el sistema:

- **Linux/Mac:** TeX Live — `sudo apt install texlive-full` o `brew install --cask mactex`
- **Windows:** MiKTeX — https://miktex.org/download

Si `pdflatex` no está disponible en el PATH, el script genera el archivo `.tex`
en `latex/reporte_MS_ciclo.tex` para compilación manual:

```bash
cd latex/
pdflatex reporte_MS_ciclo.tex
pdflatex reporte_MS_ciclo.tex   # segunda pasada para TOC
```

---

## Fundamentos metodológicos

| Componente                  | Referencia principal                         |
|-----------------------------|----------------------------------------------|
| Filtro CF asimétrico        | Christiano & Fitzgerald (2003), IER 44(2)    |
| Modelo Markov Switching     | Hamilton (1989), Econometrica 57(2)          |
| Filtro de Hamilton          | Hamilton (1989), ec. 22.4.5                  |
| Suavizador de Kim           | Kim (1994), J. Econometrics 60; Kim & Nelson (1999) |
| Algoritmo EM                | Kim & Nelson (1999), MIT Press, Cap. 4-5     |
| Datos PIB EE.UU.            | FRED — GDPC1, Federal Reserve Bank of St. Louis |

---

## Notas de compatibilidad MATLAB

- Requiere `normpdf` (Statistics and Machine Learning Toolbox)
- No requiere Optimization Toolbox (la estimación EM es completamente analítica)
- Probado en MATLAB R2019b, R2021a, R2022b y R2023a
- Compatible con Octave 7.0+ (con `statistics` package instalado)

---

## Licencia

Uso académico libre. Al usar este código en publicaciones, cite:

> Valderrama Inonan, J. (2026). *Ciclo del PIB y Probabilidades de Régimen:  
> Filtro CF Asimétrico + Markov Switching MS-MH(3)*. UNAC — Macroeconometría.

Los datos GDPC1 son provistos por el Federal Reserve Bank of St. Louis (FRED).
Consulte los términos de uso en: https://fred.stlouisfed.org/legal
