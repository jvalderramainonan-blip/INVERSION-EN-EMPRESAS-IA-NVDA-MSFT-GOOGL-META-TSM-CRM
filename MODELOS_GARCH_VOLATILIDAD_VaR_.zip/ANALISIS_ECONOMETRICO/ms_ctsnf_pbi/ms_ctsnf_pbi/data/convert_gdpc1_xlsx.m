% =========================================================================
% CONVERT_GDPC1_XLSX.M
% Convierte el archivo GDPC1.xlsx (FRED) al formato CSV requerido por
% el paquete MS-MH(3). Ejecutar desde la raiz del proyecto.
%
% USO:
%   cd('ruta/a/ms_probit_matlab')
%   run('data/convert_gdpc1_xlsx.m')
%
% ENTRADA:
%   data/GDPC1.xlsx  — Descargado directamente de:
%                      https://fred.stlouisfed.org/series/GDPC1
%
% SALIDA:
%   data/gdp_usa.csv — En formato date,gdp_real (YYYY-QN)
%
% FUENTE: FRED — Real Gross Domestic Product (GDPC1)
%         Unidades: Miles de millones de USD encadenados 2017, SAAR
%
% AUTOR: Joan Valderrama Inonan  |  UNAC - Macroeconometria
% VERSION: 1.0  |  JUNIO 2026
% =========================================================================

xlsx_path = fullfile('data', 'GDPC1.xlsx');
csv_path  = fullfile('data', 'gdp_usa.csv');

if ~exist(xlsx_path, 'file')
    error(['CONVERT_GDPC1_XLSX: No se encontro %s\n' ...
           'Descargue GDPC1.xlsx desde https://fred.stlouisfed.org/series/GDPC1\n' ...
           'y coloquelo en la carpeta data/.'], xlsx_path);
end

fprintf('Leyendo %s...\n', xlsx_path);

% Leer hoja "Quarterly" (hoja 2 en el xlsx de FRED)
T_raw = readtable(xlsx_path, 'Sheet', 'Quarterly', 'VariableNamesLine', 1);

% Columnas esperadas: observation_date | GDPC1
dates_raw = T_raw{:,1};  % datetime o char
gdp_vals  = T_raw{:,2};  % double

n = length(gdp_vals);
fprintf('   Observaciones leidas: %d\n', n);

% Convertir fechas a formato YYYY-QN
date_strs = cell(n, 1);
for i = 1:n
    if isdatetime(dates_raw(i))
        dt = dates_raw(i);
        yr = year(dt);
        mo = month(dt);
    else
        % Si vienen como datenum o char
        dv = datevec(dates_raw(i));
        yr = dv(1);
        mo = dv(2);
    end
    q = ceil(mo / 3);
    date_strs{i} = sprintf('%d-Q%d', yr, q);
end

% Escribir CSV
fid = fopen(csv_path, 'w');
fprintf(fid, 'date,gdp_real\n');
for i = 1:n
    fprintf(fid, '%s,%.3f\n', date_strs{i}, gdp_vals(i));
end
fclose(fid);

fprintf('CSV generado: %s\n', csv_path);
fprintf('Rango: %s a %s\n', date_strs{1}, date_strs{end});
fprintf('Conversion completada. Ejecute main_MS_cycle para estimar el modelo.\n');
