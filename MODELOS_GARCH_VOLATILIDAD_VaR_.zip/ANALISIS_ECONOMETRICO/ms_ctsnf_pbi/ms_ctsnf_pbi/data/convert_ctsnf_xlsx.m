% =========================================================================
% CONVERT_CTSNF_XLSX.M
% Convierte el archivo SERIE_CREDITOS_SECTOR_NO_FINANCIERO.xlsx (hoja 3)
% al formato CSV requerido por el paquete Markov Switching.
%
% USO:
%   cd('ruta/a/ms_probit_matlab')
%   run('data/convert_ctsnf_xlsx.m')
%
% ENTRADA:
%   SERIE_CREDITOS_SECTOR_NO_FINANCIERO.xlsx
%   Hoja 3: CREDITOS_AJUSTADOS_INF_ESTACION
%
% SALIDA:
%   data/ctsnf_real.csv  — formato date,ctsnf_real (YYYY-QN)
%
% NOTA:
%   Esta rutina usa especificamente la hoja 3 del Excel proporcionado.
% =========================================================================

xlsx_path = fullfile('data', 'SERIE_CREDITOS_SECTOR_NO_FINANCIERO.xlsx');
csv_path  = fullfile('data', 'ctsnf_real.csv');

if ~exist(xlsx_path, 'file')
    error(['CONVERT_CTSNF_XLSX: No se encontro %s\n' ...
           'Coloque el archivo SERIE_CREDITOS_SECTOR_NO_FINANCIERO.xlsx en la carpeta data/.'], xlsx_path);
end

fprintf('Leyendo %s...\n', xlsx_path);

% Leer la hoja 3 por indice (CREDITOS_AJUSTADOS_INF_ESTACION)
T_raw = readtable(xlsx_path, 'Sheet', 3, 'VariableNamesLine', 1);

% Se esperan columnas: FECHA | CTSNF_REAL
dates_raw = T_raw{:,1};
cts_vals  = T_raw{:,2};

n = length(cts_vals);
fprintf('   Observaciones leidas: %d\n', n);

% Convertir fechas a formato YYYY-QN
date_strs = cell(n, 1);
for i = 1:n
    s = char(dates_raw(i));
    s = strtrim(s);
    tok = regexp(s, '^(\d{4})Q(\d)$', 'tokens');
    if ~isempty(tok)
        yr  = str2double(tok{1}{1});
        qtr = str2double(tok{1}{2});
        date_strs{i} = sprintf('%d-Q%d', yr, qtr);
    else
        try
            dt = datetime(s);
            yr = year(dt); mo = month(dt);
            q = ceil(mo / 3);
            date_strs{i} = sprintf('%d-Q%d', yr, q);
        catch
            error('No se pudo interpretar la fecha: %s', s);
        end
    end
end

% Escribir CSV
fid = fopen(csv_path, 'w');
fprintf(fid, 'date,ctsnf_real\n');
for i = 1:n
    fprintf(fid, '%s,%.6f\n', date_strs{i}, cts_vals(i));
end
fclose(fid);

fprintf('CSV generado: %s\n', csv_path);
fprintf('Rango: %s a %s\n', date_strs{1}, date_strs{end});
fprintf('Conversion completada.\n');
