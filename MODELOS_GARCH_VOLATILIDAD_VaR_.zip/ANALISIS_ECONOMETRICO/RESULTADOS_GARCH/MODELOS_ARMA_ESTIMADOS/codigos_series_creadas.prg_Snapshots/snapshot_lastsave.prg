DATA NVDA MSFT GOOGL META TSM CRM 
series r_crm=log(crm/crm(-1))
series r_googl=log(googl/googl(-1))
series r_meta=log(meta/meta(-1))
series r_msft=log(msft/msft(-1))
series r_nvda=log(nvda/nvda(-1))
series r_tsm=log(tsm/tsm(-1))
series r_sp500=log(sp500/sp500(-1))
series r_nasdaq=log(nasdaq100/nasdaq100(-1))



equation eq_r_googl.ls r_googl c ar(1) 
equation eq_r_meta.ls r_meta c ar(1)
equation eq_r_msft.ls r_msft c ma(1)
equation eq_r_nvda.ls r_nvda c ar(1)

' ============================================================
' PASO 1: Convertir varianza condicional a volatilidad
' ============================================================
series SIGMA_GOOGL = sqr(volatilidad_condicional_googl)
series SIGMA_META  = sqr(volatilidad_condicional_meta)
series SIGMA_MSFT  = sqr(volatilidad_condicional_msft)
series SIGMA_NVDA  = sqr(volatilidad_condicional_nvda)

' ============================================================
' PASO 2: Volatilidad anualizada (regla ra�z cuadrada del tiempo)
' ============================================================
series SIGMA_GOOGL_ANUAL = SIGMA_GOOGL * sqr(52)
series SIGMA_META_ANUAL  = SIGMA_META  * sqr(52)
series SIGMA_MSFT_ANUAL  = SIGMA_MSFT  * sqr(52)
series SIGMA_NVDA_ANUAL  = SIGMA_NVDA  * sqr(52)


' ============================================================
' PASO 3: Alinear muestra a observaciones comunes v�lidas
' ============================================================
smpl if SIGMA_GOOGL <> na and r_googl <> na and RF_SEMANAL <> na

' ============================================================
' PASO 5: VaR din�mico semanal al 95% y 99%
' (usando volatilidad semanal, no anualizada)
' DOF por modelo �ptimo: NVDA=14.37, GOOGL=19.02, META=6.36, MSFT=13.60
' ============================================================
series VAR99_NVDA  = @qtdist(0.01, 14.37) * SIGMA_NVDA
series VAR99_GOOGL = @qtdist(0.01, 19.02) * SIGMA_GOOGL
series VAR99_META  = @qtdist(0.01,  6.36) * SIGMA_META
series VAR99_MSFT  = @qtdist(0.01, 13.60) * SIGMA_MSFT

series VAR95_NVDA  = @qtdist(0.05, 14.37) * SIGMA_NVDA
series VAR95_GOOGL = @qtdist(0.05, 19.02) * SIGMA_GOOGL
series VAR95_META  = @qtdist(0.05,  6.36) * SIGMA_META
series VAR95_MSFT  = @qtdist(0.05, 13.60) * SIGMA_MSFT

' ============================================================
' PASO 6: Escalares resumen (VaR promedio del per�odo)
' ============================================================
scalar VAR99_NVDA_PROM  = @mean(VAR99_NVDA)
scalar VAR99_GOOGL_PROM = @mean(VAR99_GOOGL)
scalar VAR99_META_PROM  = @mean(VAR99_META)
scalar VAR99_MSFT_PROM  = @mean(VAR99_MSFT)

scalar VAR95_NVDA_PROM  = @mean(VAR95_NVDA)
scalar VAR95_GOOGL_PROM = @mean(VAR95_GOOGL)
scalar VAR95_META_PROM  = @mean(VAR95_META)
scalar VAR95_MSFT_PROM  = @mean(VAR95_MSFT)

' ============================================================
' PASO 7: Sharpe Ratio condicional anualizado
' ============================================================
series SR_NVDA  = (r_nvda  - RF_SEMANAL) / SIGMA_NVDA
series SR_GOOGL = (r_googl - RF_SEMANAL) / SIGMA_GOOGL
series SR_META  = (r_meta  - RF_SEMANAL) / SIGMA_META
series SR_MSFT  = (r_msft  - RF_SEMANAL) / SIGMA_MSFT

scalar SR_NVDA_ANUAL  = @mean(SR_NVDA)  * sqr(52)
scalar SR_GOOGL_ANUAL = @mean(SR_GOOGL) * sqr(52)
scalar SR_META_ANUAL  = @mean(SR_META)  * sqr(52)
scalar SR_MSFT_ANUAL  = @mean(SR_MSFT)  * sqr(52)

' ============================================================
' PASO 8: Volatilidad media anualizada (escalar para tabla)
' ============================================================
scalar SIGMA_NVDA_PROM  = @mean(SIGMA_NVDA_ANUAL)
scalar SIGMA_GOOGL_PROM = @mean(SIGMA_GOOGL_ANUAL)
scalar SIGMA_META_PROM  = @mean(SIGMA_META_ANUAL)
scalar SIGMA_MSFT_PROM  = @mean(SIGMA_MSFT_ANUAL)

' ============================================================
' PASO 9: Restaurar muestra completa
' ============================================================
smpl @all
