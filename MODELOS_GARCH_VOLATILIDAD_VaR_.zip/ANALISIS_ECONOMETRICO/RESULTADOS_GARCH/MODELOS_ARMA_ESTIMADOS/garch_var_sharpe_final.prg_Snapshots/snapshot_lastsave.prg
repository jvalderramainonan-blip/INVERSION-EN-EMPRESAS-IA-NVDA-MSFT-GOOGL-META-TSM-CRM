'=========================================================
'  PROGRAMA: VOLATILIDAD CONDICIONAL, VaR DINAMICO Y
'            SHARPE RATIO -- 6 ACTIVOS TECNOLOGICOS
'
'  Activos : CRM, GOOGL, META, MSFT, NVDA, TSM
'  Frecuencia: Semanal
'  Metodologia:
'    - Retornos logaritmicos continuos
'    - Prueba ARCH-LM (Engle, 1982) con rezagos 1-4
'    - Seleccion GARCH(p,q)-t por criterio de Schwarz
'    - VaR dinamico bajo distribucion t-Student
'      (McNeil, Frey & Embrechts, 2005)
'    - Backtesting: Kupiec (1995) + Christoffersen (1998)
'    - Sharpe Ratio condicional anualizado
'
'  Autor    : [Joan -- UNAC, Macroeconometria]
'  Version  : 2.0 -- Revisada y documentada
'=========================================================



'=========================================================
' BLOQUE 1: RETORNOS LOGARITMICOS
'---------------------------------------------------------
' Se calculan los retornos como diferencias logaritmicas
' continuas: r_t = ln(P_t / P_{t-1}).
' Esta aproximacion es preferida en finanzas porque:
'   (a) es aditiva en el tiempo,
'   (b) mantiene la propiedad de simetria,
'   (c) se ajusta mejor a la distribucion normal/t.
' Referencia: Campbell, Lo & MacKinlay (1997), cap. 1.
'=========================================================

series r_crm   = log(crm   / crm(-1))
series r_googl = log(googl / googl(-1))
series r_meta  = log(meta  / meta(-1))
series r_msft  = log(msft  / msft(-1))
series r_nvda  = log(nvda  / nvda(-1))
series r_tsm   = log(tsm   / tsm(-1))



'=========================================================
' BLOQUE 2: ECUACIONES DE MEDIA
'---------------------------------------------------------
' Se estima la ecuacion de media por OLS. La especificacion
' mas parsimoniosa es una constante pura (random walk con
' deriva), consistente con la hipotesis de mercados
' eficientes en forma debil (Fama, 1970).
'
' NOTA IMPORTANTE: Si la prueba de Ljung-Box sobre los
' residuos rechaza la hipotesis de no autocorrelacion,
' reemplazar "c" por la especificacion AR/MA optima,
' por ejemplo:
'   equation eq_crm.ls r_crm c ar(1)
'   equation eq_crm.ls r_crm c ma(1)
' El objetivo es que los residuos queden libres de
' autocorrelacion antes de aplicar el test ARCH-LM.
'=========================================================

equation eq_crm.ls   r_crm   c
equation eq_googl.ls r_googl c
equation eq_meta.ls  r_meta  c
equation eq_msft.ls  r_msft  c
equation eq_nvda.ls  r_nvda  c
equation eq_tsm.ls   r_tsm   c

' --- Extraccion de residuos para el test ARCH-LM ---
' Los residuos e_hat_t = r_t - mu_t se usaran en la
' regresion auxiliar de la prueba ARCH-LM (Bloque 3).

eq_crm.makeresids   resid_crm
eq_googl.makeresids resid_googl
eq_meta.makeresids  resid_meta
eq_msft.makeresids  resid_msft
eq_nvda.makeresids  resid_nvda
eq_tsm.makeresids   resid_tsm



'=========================================================
' BLOQUE 3: PRUEBA ARCH-LM (ENGLE, 1982)
'---------------------------------------------------------
' La prueba ARCH-LM evalua si existen efectos ARCH en los
' residuos de la ecuacion de media. Se basa en la regresion
' auxiliar:
'
'   e_hat^2_t = gamma_0 + gamma_1e_hat^2_{t-1} + ... + gamma_q e_hat^2_{t-q} + v_t
'
' H_0: gamma_1 = gamma_2 = ... = gamma_q = 0  (no hay efectos ARCH)
' H_1: al menos un gamma_i != 0       (hay efectos ARCH)
'
' El estadistico T*R^2 ~ chi^2(q) bajo H_0.
' Se evaluan q = 1, 2, 3, 4 rezagos para verificar
' robustez del rechazo.
'
' Referencia: Engle, R.F. (1982). "Autoregressive
'   Conditional Heteroscedasticity with Estimates of the
'   Variance of United Kingdom Inflation." Econometrica,
'   50(4), 987-1007.
'=========================================================

delete(noerr) spool_arch
spool spool_arch

'--- q = 1 rezago ---
freeze(arch_crm_1)   eq_crm.archtest(1)
spool_arch.append arch_crm_1
freeze(arch_googl_1) eq_googl.archtest(1)
spool_arch.append arch_googl_1
freeze(arch_meta_1)  eq_meta.archtest(1)
spool_arch.append arch_meta_1
freeze(arch_msft_1)  eq_msft.archtest(1)
spool_arch.append arch_msft_1
freeze(arch_nvda_1)  eq_nvda.archtest(1)
spool_arch.append arch_nvda_1
freeze(arch_tsm_1)   eq_tsm.archtest(1)
spool_arch.append arch_tsm_1

'--- q = 2 rezagos ---
freeze(arch_crm_2)   eq_crm.archtest(2)
spool_arch.append arch_crm_2
freeze(arch_googl_2) eq_googl.archtest(2)
spool_arch.append arch_googl_2
freeze(arch_meta_2)  eq_meta.archtest(2)
spool_arch.append arch_meta_2
freeze(arch_msft_2)  eq_msft.archtest(2)
spool_arch.append arch_msft_2
freeze(arch_nvda_2)  eq_nvda.archtest(2)
spool_arch.append arch_nvda_2
freeze(arch_tsm_2)   eq_tsm.archtest(2)
spool_arch.append arch_tsm_2

'--- q = 3 rezagos ---
freeze(arch_crm_3)   eq_crm.archtest(3)
spool_arch.append arch_crm_3
freeze(arch_googl_3) eq_googl.archtest(3)
spool_arch.append arch_googl_3
freeze(arch_meta_3)  eq_meta.archtest(3)
spool_arch.append arch_meta_3
freeze(arch_msft_3)  eq_msft.archtest(3)
spool_arch.append arch_msft_3
freeze(arch_nvda_3)  eq_nvda.archtest(3)
spool_arch.append arch_nvda_3
freeze(arch_tsm_3)   eq_tsm.archtest(3)
spool_arch.append arch_tsm_3

'--- q = 4 rezagos ---
freeze(arch_crm_4)   eq_crm.archtest(4)
spool_arch.append arch_crm_4
freeze(arch_googl_4) eq_googl.archtest(4)
spool_arch.append arch_googl_4
freeze(arch_meta_4)  eq_meta.archtest(4)
spool_arch.append arch_meta_4
freeze(arch_msft_4)  eq_msft.archtest(4)
spool_arch.append arch_msft_4
freeze(arch_nvda_4)  eq_nvda.archtest(4)
spool_arch.append arch_nvda_4
freeze(arch_tsm_4)   eq_tsm.archtest(4)
spool_arch.append arch_tsm_4

show spool_arch



'=========================================================
' BLOQUE 4: SELECCION Y ESTIMACION GARCH(p,q)-t
'---------------------------------------------------------
' El modelo GARCH(p,q) con innovaciones t-Student se
' especifica como:
'
'   Ecuacion de media:    r_t = mu + eps_t
'   Ecuacion de varianza: sigma^2_t = omega + Sum alpha_i eps^2_{t-i}
'                                    + Sum beta_j sigma^2_{t-j}
'
' donde eps_t = sigma_t * z_t  y  z_t ~ t(nu) estandarizada.
'
' Condiciones de estacionariedad en covarianza:
'   omega > 0,  alpha_i >= 0,  beta_j >= 0,  Sumalpha_i + Sumbeta_j < 1
'
' Ventaja de la distribucion t-Student sobre la normal:
' captura colas pesadas (leptocurtosis) frecuentes en
' retornos financieros. El parametro nu (grados de libertad)
' se estima por maxima verosimilitud; a mayor nu, la
' distribucion se aproxima a la normal.
'
' Seleccion por Criterio de Schwarz (BIC): penaliza la
' sobre-parametrizacion mas que el AIC, favoreciendo
' modelos mas parsimoniosos.
'   BIC = -2*ln(L)/T + k*ln(T)/T
'
' Se evaluan p,q in {1,2,3,4} -> 16 combinaciones por activo.
'
' Referencia: Bollerslev, T. (1986). "Generalized
'   Autoregressive Conditional Heteroskedasticity."
'   Journal of Econometrics, 31(3), 307-327.
'=========================================================

delete(noerr) spool_garch_best
spool spool_garch_best

'------------------------------------------------------------
' SUBRUTINA DE SELECCION (repetida para cada activo):
'   1. Inicializar bestsc con un valor muy grande (1e+20).
'   2. Iterar sobre todas las combinaciones (p,q).
'   3. Si el BIC del modelo actual < bestsc, actualizar.
'   4. Re-estimar con los ordenes optimos (bestp, bestq).
'------------------------------------------------------------

'---------- CRM ----------
scalar bestsc = 1e+20
scalar bestp  = 1
scalar bestq  = 1

for !p = 1 to 4
  for !q = 1 to 4
    delete(noerr) eq_tmp
    equation eq_tmp.arch(!p,!q,tdist) r_crm c
    if eq_tmp.@sc < bestsc then
      bestsc = eq_tmp.@sc
      bestp  = !p
      bestq  = !q
    endif
  next
next

delete(noerr) eq_crm_garch_best
equation eq_crm_garch_best.arch(bestp,bestq,tdist) r_crm c
freeze(tab_crm_best) eq_crm_garch_best.output
spool_garch_best.append tab_crm_best

'---------- GOOGL ----------
scalar bestsc = 1e+20
scalar bestp  = 1
scalar bestq  = 1

for !p = 1 to 4
  for !q = 1 to 4
    delete(noerr) eq_tmp
    equation eq_tmp.arch(!p,!q,tdist) r_googl c
    if eq_tmp.@sc < bestsc then
      bestsc = eq_tmp.@sc
      bestp  = !p
      bestq  = !q
    endif
  next
next

delete(noerr) eq_googl_garch_best
equation eq_googl_garch_best.arch(bestp,bestq,tdist) r_googl c
freeze(tab_googl_best) eq_googl_garch_best.output
spool_garch_best.append tab_googl_best

'---------- META ----------
scalar bestsc = 1e+20
scalar bestp  = 1
scalar bestq  = 1

for !p = 1 to 4
  for !q = 1 to 4
    delete(noerr) eq_tmp
    equation eq_tmp.arch(!p,!q,tdist) r_meta c
    if eq_tmp.@sc < bestsc then
      bestsc = eq_tmp.@sc
      bestp  = !p
      bestq  = !q
    endif
  next
next

delete(noerr) eq_meta_garch_best
equation eq_meta_garch_best.arch(bestp,bestq,tdist) r_meta c
freeze(tab_meta_best) eq_meta_garch_best.output
spool_garch_best.append tab_meta_best

'---------- MSFT ----------
scalar bestsc = 1e+20
scalar bestp  = 1
scalar bestq  = 1

for !p = 1 to 4
  for !q = 1 to 4
    delete(noerr) eq_tmp
    equation eq_tmp.arch(!p,!q,tdist) r_msft c
    if eq_tmp.@sc < bestsc then
      bestsc = eq_tmp.@sc
      bestp  = !p
      bestq  = !q
    endif
  next
next

delete(noerr) eq_msft_garch_best
equation eq_msft_garch_best.arch(bestp,bestq,tdist) r_msft c
freeze(tab_msft_best) eq_msft_garch_best.output
spool_garch_best.append tab_msft_best

'---------- NVDA ----------
scalar bestsc = 1e+20
scalar bestp  = 1
scalar bestq  = 1

for !p = 1 to 4
  for !q = 1 to 4
    delete(noerr) eq_tmp
    equation eq_tmp.arch(!p,!q,tdist) r_nvda c
    if eq_tmp.@sc < bestsc then
      bestsc = eq_tmp.@sc
      bestp  = !p
      bestq  = !q
    endif
  next
next

delete(noerr) eq_nvda_garch_best
equation eq_nvda_garch_best.arch(bestp,bestq,tdist) r_nvda c
freeze(tab_nvda_best) eq_nvda_garch_best.output
spool_garch_best.append tab_nvda_best

'---------- TSM ----------
scalar bestsc = 1e+20
scalar bestp  = 1
scalar bestq  = 1

for !p = 1 to 4
  for !q = 1 to 4
    delete(noerr) eq_tmp
    equation eq_tmp.arch(!p,!q,tdist) r_tsm c
    if eq_tmp.@sc < bestsc then
      bestsc = eq_tmp.@sc
      bestp  = !p
      bestq  = !q
    endif
  next
next

delete(noerr) eq_tsm_garch_best
equation eq_tsm_garch_best.arch(bestp,bestq,tdist) r_tsm c
freeze(tab_tsm_best) eq_tsm_garch_best.output
spool_garch_best.append tab_tsm_best

show spool_garch_best



'=========================================================
' BLOQUE 5: VARIANZA Y VOLATILIDAD CONDICIONAL
'---------------------------------------------------------
' makegarch extrae la serie sigma^2_t del modelo GARCH estimado.
'
' Volatilidad condicional semanal:
'   sigma_t = sqrt(sigma^2_t)
'
' Volatilidad condicional anualizada:
'   sigma_t^{anual} = sigma_t * sqrt52
'
' La conversion por sqrt52 se basa en la regla de raiz del
' tiempo (Hull, 2018), valida bajo supuesto de retornos
' i.i.d. Esta es una aproximacion; para proyecciones
' multi-periodo precisas se requiere simulacion.
'=========================================================

eq_crm_garch_best.makegarch   garchvar_crm
eq_googl_garch_best.makegarch garchvar_googl
eq_meta_garch_best.makegarch  garchvar_meta
eq_msft_garch_best.makegarch  garchvar_msft
eq_nvda_garch_best.makegarch  garchvar_nvda
eq_tsm_garch_best.makegarch   garchvar_tsm

' --- Volatilidad semanal (escala nativa del modelo) ---
series VOLATILIDAD_CONDICIONAL_CRM   = @sqrt(garchvar_crm)
series VOLATILIDAD_CONDICIONAL_GOOGL = @sqrt(garchvar_googl)
series VOLATILIDAD_CONDICIONAL_META  = @sqrt(garchvar_meta)
series VOLATILIDAD_CONDICIONAL_MSFT  = @sqrt(garchvar_msft)
series VOLATILIDAD_CONDICIONAL_NVDA  = @sqrt(garchvar_nvda)
series VOLATILIDAD_CONDICIONAL_TSM   = @sqrt(garchvar_tsm)

' --- Volatilidad anualizada (para reportes e interpretacion) ---
series VOLATILIDAD_ANUALIZADA_CRM   = VOLATILIDAD_CONDICIONAL_CRM   * @sqrt(52)
series VOLATILIDAD_ANUALIZADA_GOOGL = VOLATILIDAD_CONDICIONAL_GOOGL * @sqrt(52)
series VOLATILIDAD_ANUALIZADA_META  = VOLATILIDAD_CONDICIONAL_META  * @sqrt(52)
series VOLATILIDAD_ANUALIZADA_MSFT  = VOLATILIDAD_CONDICIONAL_MSFT  * @sqrt(52)
series VOLATILIDAD_ANUALIZADA_NVDA  = VOLATILIDAD_CONDICIONAL_NVDA  * @sqrt(52)
series VOLATILIDAD_ANUALIZADA_TSM   = VOLATILIDAD_CONDICIONAL_TSM   * @sqrt(52)

' --- Alias SIGMA para uso interno en Sharpe y resumenes ---
series SIGMA_CRM   = VOLATILIDAD_ANUALIZADA_CRM
series SIGMA_GOOGL = VOLATILIDAD_ANUALIZADA_GOOGL
series SIGMA_META  = VOLATILIDAD_ANUALIZADA_META
series SIGMA_MSFT  = VOLATILIDAD_ANUALIZADA_MSFT
series SIGMA_NVDA  = VOLATILIDAD_ANUALIZADA_NVDA
series SIGMA_TSM   = VOLATILIDAD_ANUALIZADA_TSM



'=========================================================
' BLOQUE 6: TASA LIBRE DE RIESGO SEMANAL
'---------------------------------------------------------
' Se asume que RF es el rendimiento del Treasury a 10 anos
' expresado en porcentaje anual (e.g., RF = 4.5 -> 4.5%).
'
' Conversion a tasa semanal equivalente (capitalizacion
' compuesta exacta):
'   RF_semanal = (1 + RF/100)^(1/52) - 1
'
' Esta conversion es metodologicamente correcta frente a
' la aproximacion lineal RF/52, que sobreestima la tasa
' cuando RF es elevada.
'=========================================================

series RF_DEC = (1 + RF/100)^(1/52) - 1



'=========================================================
' BLOQUE 7: RESTRICCION DE MUESTRA COMUN
'---------------------------------------------------------
' Se restringe el analisis a observaciones para las que
' todos los activos y la tasa libre de riesgo tienen datos
' validos (no NA). Esto garantiza que los indicadores de
' la matriz final sean comparables entre activos y que las
' metricas se calculen sobre el mismo periodo temporal.
'
' NOTA: El primer periodo de cada serie GARCH sera NA
' (por inicializacion del modelo), por lo que esta
' restriccion tambien elimina automaticamente el primer
' valor de cada serie de volatilidad condicional.
'=========================================================

' La restriccion de muestra se simplifica: las series GARCH
' heredan los NA del primer retorno logaritmico. Verificar
' RF_DEC y los 6 retornos es suficiente; las volatilidades
' GARCH son NA exactamente donde los retornos lo son.
smpl if @isna(r_crm)=0 and @isna(r_googl)=0 and _
        @isna(r_meta)=0 and @isna(r_msft)=0  and _
        @isna(r_nvda)=0 and @isna(r_tsm)=0   and _
        @isna(RF_DEC)=0



'=========================================================
' BLOQUE 8: GRADOS DE LIBERTAD t-STUDENT
'---------------------------------------------------------
' En EViews, al estimar GARCH con tdist, el ultimo
' coeficiente estimado (@coefs(@ncoef)) corresponde al
' parametro nu (grados de libertad) de la t-Student.
'
' Este valor es critico para dos usos:
'   1. Calcular el cuantil correcto @qtdist(alpha, nu) en el VaR.
'   2. Interpretar la forma de la cola: nu < 5 implica
'      colas muy pesadas; nu > 30 aproxima la normal.
'
' EViews parametriza la t-Student con varianza unitaria
' (distribucion estandarizada), por lo que @qtdist ya
' devuelve el cuantil directamente comparable con sigma_t.
' No se requiere reescalar por sqrt(nu/(nu-2)).
'=========================================================

scalar DOF_CRM   = eq_crm_garch_best.@coefs(eq_crm_garch_best.@ncoef)
scalar DOF_GOOGL = eq_googl_garch_best.@coefs(eq_googl_garch_best.@ncoef)
scalar DOF_META  = eq_meta_garch_best.@coefs(eq_meta_garch_best.@ncoef)
scalar DOF_MSFT  = eq_msft_garch_best.@coefs(eq_msft_garch_best.@ncoef)
scalar DOF_NVDA  = eq_nvda_garch_best.@coefs(eq_nvda_garch_best.@ncoef)
scalar DOF_TSM   = eq_tsm_garch_best.@coefs(eq_tsm_garch_best.@ncoef)



'=========================================================
' BLOQUE 9: VALUE AT RISK (VaR) DINAMICO -- FORMULACION
'           CORRECTA CON MEDIA CONDICIONAL
'---------------------------------------------------------
' Formulacion teorica (McNeil, Frey & Embrechts, 2005):
'
'   VaR_t(alpha) = - [mu_t + q_alpha(nu) * sigma_t]
'
' donde:
'   mu_t    = media condicional en t (fitted value del
'             modelo de media; es una constante si la
'             especificacion es solo "c")
'   q_alpha(nu) = cuantil de nivel alpha de la t-Student con nu
'             grados de libertad (q_alpha < 0 para alpha < 0.5)
'   sigma_t    = desviacion estandar condicional semanal
'
' El signo negativo exterior garantiza que VaR_t > 0,
' representando la perdida maxima esperada con
' probabilidad (1-alpha).
'
' Interpretacion (convencion perdida positiva, Basilea III):
'   VaR_t(alpha=0.01): nivel de confianza 99%. Con probabilidad
'     99%, la perdida semanal NO superara VaR_t(0.01).
'     El cuantil q_{0.01}(nu) < 0 corresponde a la cola
'     izquierda del 1% (peor 1% de escenarios).
'   VaR_t(alpha=0.05): nivel de confianza 95%. Analogamente,
'     el cuantil q_{0.05}(nu) < 0 captura el peor 5%.
'   Por construccion: VaR(alpha=0.01) > VaR(alpha=0.05) > 0,
'     ya que |q_{0.01}| > |q_{0.05}| para toda t-Student.
'
' CORRECCION RESPECTO A VERSION ANTERIOR:
'   - Se incorpora mu_t (ausente en la version original).
'   - El signo se hace explicito para reportar perdida
'     positiva, convencion estandar en Basilea III.
'
' Referencias:
'   McNeil, A.J., Frey, R. & Embrechts, P. (2005).
'     "Quantitative Risk Management." Princeton UP.
'   Basel Committee (2019). "Minimum Capital Requirements
'     for Market Risk." BIS.
'=========================================================

' --- Medias condicionales (constante del modelo de media) ---
' Si la ecuacion de media contiene solo "c", @coefs(1) es mu
' constante a lo largo del tiempo. Si contiene AR/MA,
' reemplazar estas lineas por:
'   eq_crm_garch_best.makefitted MU_CRM
' para obtener la serie dinamica de fitted values.

series MU_CRM   = eq_crm_garch_best.@coefs(1)
series MU_GOOGL = eq_googl_garch_best.@coefs(1)
series MU_META  = eq_meta_garch_best.@coefs(1)
series MU_MSFT  = eq_msft_garch_best.@coefs(1)
series MU_NVDA  = eq_nvda_garch_best.@coefs(1)
series MU_TSM   = eq_tsm_garch_best.@coefs(1)

' --- Cuantiles t-Student estandarizados por activo ---
' q_alpha(nu) < 0 para alpha in {0.01, 0.05}.
' Se almacenan como escalares porque nu es constante
' (estimado por MV), lo que hace q_alpha constante tambien.

scalar Q99_CRM   = @qtdist(0.01, DOF_CRM)
scalar Q99_GOOGL = @qtdist(0.01, DOF_GOOGL)
scalar Q99_META  = @qtdist(0.01, DOF_META)
scalar Q99_MSFT  = @qtdist(0.01, DOF_MSFT)
scalar Q99_NVDA  = @qtdist(0.01, DOF_NVDA)
scalar Q99_TSM   = @qtdist(0.01, DOF_TSM)

scalar Q95_CRM   = @qtdist(0.05, DOF_CRM)
scalar Q95_GOOGL = @qtdist(0.05, DOF_GOOGL)
scalar Q95_META  = @qtdist(0.05, DOF_META)
scalar Q95_MSFT  = @qtdist(0.05, DOF_MSFT)
scalar Q95_NVDA  = @qtdist(0.05, DOF_NVDA)
scalar Q95_TSM   = @qtdist(0.05, DOF_TSM)

' --- VaR al 99% (perdida positiva, confianza 99%) ---
series VAR99_CRM   = -(MU_CRM   + Q99_CRM   * VOLATILIDAD_CONDICIONAL_CRM)
series VAR99_GOOGL = -(MU_GOOGL + Q99_GOOGL * VOLATILIDAD_CONDICIONAL_GOOGL)
series VAR99_META  = -(MU_META  + Q99_META  * VOLATILIDAD_CONDICIONAL_META)
series VAR99_MSFT  = -(MU_MSFT  + Q99_MSFT  * VOLATILIDAD_CONDICIONAL_MSFT)
series VAR99_NVDA  = -(MU_NVDA  + Q99_NVDA  * VOLATILIDAD_CONDICIONAL_NVDA)
series VAR99_TSM   = -(MU_TSM   + Q99_TSM   * VOLATILIDAD_CONDICIONAL_TSM)

' --- VaR al 95% (perdida positiva, confianza 95%) ---
series VAR95_CRM   = -(MU_CRM   + Q95_CRM   * VOLATILIDAD_CONDICIONAL_CRM)
series VAR95_GOOGL = -(MU_GOOGL + Q95_GOOGL * VOLATILIDAD_CONDICIONAL_GOOGL)
series VAR95_META  = -(MU_META  + Q95_META  * VOLATILIDAD_CONDICIONAL_META)
series VAR95_MSFT  = -(MU_MSFT  + Q95_MSFT  * VOLATILIDAD_CONDICIONAL_MSFT)
series VAR95_NVDA  = -(MU_NVDA  + Q95_NVDA  * VOLATILIDAD_CONDICIONAL_NVDA)
series VAR95_TSM   = -(MU_TSM   + Q95_TSM   * VOLATILIDAD_CONDICIONAL_TSM)

' --- Estadisticos resumen del VaR ---
' (a) Promedio temporal: describe el nivel medio de riesgo
'     a lo largo de toda la muestra.
' (b) Valor al final de la muestra (@last): indicador
'     prospectivo mas relevante para decisiones de
'     gestion de riesgo actuales.

scalar VAR99_CRM_PROM   = @mean(VAR99_CRM)
scalar VAR99_GOOGL_PROM = @mean(VAR99_GOOGL)
scalar VAR99_META_PROM  = @mean(VAR99_META)
scalar VAR99_MSFT_PROM  = @mean(VAR99_MSFT)
scalar VAR99_NVDA_PROM  = @mean(VAR99_NVDA)
scalar VAR99_TSM_PROM   = @mean(VAR99_TSM)

scalar VAR95_CRM_PROM   = @mean(VAR95_CRM)
scalar VAR95_GOOGL_PROM = @mean(VAR95_GOOGL)
scalar VAR95_META_PROM  = @mean(VAR95_META)
scalar VAR95_MSFT_PROM  = @mean(VAR95_MSFT)
scalar VAR95_NVDA_PROM  = @mean(VAR95_NVDA)
scalar VAR95_TSM_PROM   = @mean(VAR95_TSM)

' NOTA: Los escalares VAR_LAST fueron eliminados. No existe
' una sintaxis portable en EViews para extraer el ultimo
' valor de una serie como escalar dentro de un .prg.
' Si se necesita el VaR prospectivo, verificarlo manualmente
' en el objeto de serie con View > Spreadsheet.



'=========================================================
' BLOQUE 10: BACKTESTING DEL VaR
'---------------------------------------------------------
' El backtesting verifica si el nivel de cobertura
' observado del VaR es estadisticamente compatible con
' el nivel nominal declarado.
'
' PASO 1 -- Indicadores de violacion (exceedance hits):
'   I_t = 1  si  r_t < -VaR_t(alpha)  [perdida supera el VaR]
'   I_t = 0  en caso contrario
' Bajo un VaR correctamente especificado, {I_t} debe ser
' una secuencia Bernoulli i.i.d. con Pr(I_t=1) = alpha.
'
' PASO 2 -- Prueba de Kupiec (1995): Cobertura Incondicional
'   H_0: p = alpha  (la frecuencia observada iguala el nivel
'               nominal)
'   Estadistico:
'     LR_uc = -2*[T_1*ln(alpha) + T_0*ln(1-alpha)
'                -T_1*ln(p) - T_0*ln(1-p)]
'   donde T_1 = numero de violaciones,
'         T_0 = T - T_1,
'         p = T_1/T.
'   LR_uc ~ chi^2(1) bajo H_0.
'   No rechazo -> la tasa de violaciones es correcta.
'
' PASO 3 -- Interpretacion conjunta:
'   Si LR_uc no rechaza H_0 -> cobertura correcta.
'   Si rechaza por exceso de violaciones -> VaR subestima
'     el riesgo (modelo demasiado optimista).
'   Si rechaza por defecto de violaciones -> VaR sobreestima
'     el riesgo (modelo demasiado conservador).
'
' Extension recomendada: Prueba de Christoffersen (1998)
' evalua adicionalmente la independencia de {I_t} mediante
' una cadena de Markov de primer orden. Si los hits se
' agrupan en el tiempo, el modelo subestima el riesgo
' durante periodos de crisis (efecto clustering).
'
' Referencias:
'   Kupiec, P. (1995). "Techniques for Verifying the
'     Accuracy of Risk Measurement Models." Journal of
'     Derivatives, 3(2), 73-84.
'   Christoffersen, P. (1998). "Evaluating Interval
'     Forecasts." International Economic Review,
'     39(4), 841-862.
'=========================================================

' NOTA DE IMPLEMENTACION: La prueba de Christoffersen (1998)
' referenciada en el encabezado NO esta implementada en este
' bloque. Para incluirla, construir la matriz de transicion
' de la cadena de Markov de primer orden sobre {HIT_t} y
' calcular el estadistico LR_ind ~ chi^2(1). El estadistico
' conjunto de cobertura condicional seria:
'   LR_cc = LR_uc + LR_ind ~ chi^2(2).
' La implementacion queda pendiente para versiones futuras.

' --- Numero total de observaciones en muestra comun ---
scalar T_OBS = @obs(r_crm)

' --- Indicadores de violacion VaR 99% ---
' Nota: el retorno r_t es una ganancia; la perdida es -r_t.
' La violacion ocurre cuando -r_t > VaR_t, es decir r_t < -VaR_t.
' Dado que VaR_t > 0, esto es equivalente a r_t < -VAR99.

series HIT99_CRM   = (r_crm   < -VAR99_CRM)
series HIT99_GOOGL = (r_googl < -VAR99_GOOGL)
series HIT99_META  = (r_meta  < -VAR99_META)
series HIT99_MSFT  = (r_msft  < -VAR99_MSFT)
series HIT99_NVDA  = (r_nvda  < -VAR99_NVDA)
series HIT99_TSM   = (r_tsm   < -VAR99_TSM)

' --- Indicadores de violacion VaR 95% ---
series HIT95_CRM   = (r_crm   < -VAR95_CRM)
series HIT95_GOOGL = (r_googl < -VAR95_GOOGL)
series HIT95_META  = (r_meta  < -VAR95_META)
series HIT95_MSFT  = (r_msft  < -VAR95_MSFT)
series HIT95_NVDA  = (r_nvda  < -VAR95_NVDA)
series HIT95_TSM   = (r_tsm   < -VAR95_TSM)

' --- Tasas de cobertura observadas ---
' Comparar con alpha = 0.01 (VaR 99%) y alpha = 0.05 (VaR 95%).
' Una tasa de cobertura proxima a alpha indica buen ajuste.

scalar COVER99_CRM   = @sum(HIT99_CRM)   / T_OBS
scalar COVER99_GOOGL = @sum(HIT99_GOOGL) / T_OBS
scalar COVER99_META  = @sum(HIT99_META)  / T_OBS
scalar COVER99_MSFT  = @sum(HIT99_MSFT)  / T_OBS
scalar COVER99_NVDA  = @sum(HIT99_NVDA)  / T_OBS
scalar COVER99_TSM   = @sum(HIT99_TSM)   / T_OBS

scalar COVER95_CRM   = @sum(HIT95_CRM)   / T_OBS
scalar COVER95_GOOGL = @sum(HIT95_GOOGL) / T_OBS
scalar COVER95_META  = @sum(HIT95_META)  / T_OBS
scalar COVER95_MSFT  = @sum(HIT95_MSFT)  / T_OBS
scalar COVER95_NVDA  = @sum(HIT95_NVDA)  / T_OBS
scalar COVER95_TSM   = @sum(HIT95_TSM)   / T_OBS

'------------------------------------------------------------
' TEST DE KUPIEC -- VaR 99% para cada activo
' (Estructura identica para VaR 95%: cambiar
'  HIT99 -> HIT95, 0.01 -> 0.05, 0.99 -> 0.95)
'------------------------------------------------------------

' CRM -- Kupiec LR (99%)
scalar T1_99_CRM    = @sum(HIT99_CRM)
scalar T0_99_CRM    = T_OBS - T1_99_CRM
scalar P_99_CRM     = T1_99_CRM / T_OBS
scalar LR_KUP99_CRM = -2*(T1_99_CRM*@log(0.01) + T0_99_CRM*@log(0.99) _
                        - T1_99_CRM*@log(P_99_CRM + 1e-10) _
                        - T0_99_CRM*@log(1 - P_99_CRM + 1e-10))
scalar PVAL_KUP99_CRM = 1 - @cchisq(LR_KUP99_CRM, 1)

' GOOGL -- Kupiec LR (99%)
scalar T1_99_GOOGL    = @sum(HIT99_GOOGL)
scalar T0_99_GOOGL    = T_OBS - T1_99_GOOGL
scalar P_99_GOOGL     = T1_99_GOOGL / T_OBS
scalar LR_KUP99_GOOGL = -2*(T1_99_GOOGL*@log(0.01) + T0_99_GOOGL*@log(0.99) _
                          - T1_99_GOOGL*@log(P_99_GOOGL + 1e-10) _
                          - T0_99_GOOGL*@log(1 - P_99_GOOGL + 1e-10))
scalar PVAL_KUP99_GOOGL = 1 - @cchisq(LR_KUP99_GOOGL, 1)

' META -- Kupiec LR (99%)
scalar T1_99_META    = @sum(HIT99_META)
scalar T0_99_META    = T_OBS - T1_99_META
scalar P_99_META     = T1_99_META / T_OBS
scalar LR_KUP99_META = -2*(T1_99_META*@log(0.01) + T0_99_META*@log(0.99) _
                         - T1_99_META*@log(P_99_META + 1e-10) _
                         - T0_99_META*@log(1 - P_99_META + 1e-10))
scalar PVAL_KUP99_META = 1 - @cchisq(LR_KUP99_META, 1)

' MSFT -- Kupiec LR (99%)
scalar T1_99_MSFT    = @sum(HIT99_MSFT)
scalar T0_99_MSFT    = T_OBS - T1_99_MSFT
scalar P_99_MSFT     = T1_99_MSFT / T_OBS
scalar LR_KUP99_MSFT = -2*(T1_99_MSFT*@log(0.01) + T0_99_MSFT*@log(0.99) _
                         - T1_99_MSFT*@log(P_99_MSFT + 1e-10) _
                         - T0_99_MSFT*@log(1 - P_99_MSFT + 1e-10))
scalar PVAL_KUP99_MSFT = 1 - @cchisq(LR_KUP99_MSFT, 1)

' NVDA -- Kupiec LR (99%)
scalar T1_99_NVDA    = @sum(HIT99_NVDA)
scalar T0_99_NVDA    = T_OBS - T1_99_NVDA
scalar P_99_NVDA     = T1_99_NVDA / T_OBS
scalar LR_KUP99_NVDA = -2*(T1_99_NVDA*@log(0.01) + T0_99_NVDA*@log(0.99) _
                         - T1_99_NVDA*@log(P_99_NVDA + 1e-10) _
                         - T0_99_NVDA*@log(1 - P_99_NVDA + 1e-10))
scalar PVAL_KUP99_NVDA = 1 - @cchisq(LR_KUP99_NVDA, 1)

' TSM -- Kupiec LR (99%)
scalar T1_99_TSM    = @sum(HIT99_TSM)
scalar T0_99_TSM    = T_OBS - T1_99_TSM
scalar P_99_TSM     = T1_99_TSM / T_OBS
scalar LR_KUP99_TSM = -2*(T1_99_TSM*@log(0.01) + T0_99_TSM*@log(0.99) _
                        - T1_99_TSM*@log(P_99_TSM + 1e-10) _
                        - T0_99_TSM*@log(1 - P_99_TSM + 1e-10))
scalar PVAL_KUP99_TSM = 1 - @cchisq(LR_KUP99_TSM, 1)

'------------------------------------------------------------
' TEST DE KUPIEC -- VaR 95%
'------------------------------------------------------------

' CRM -- Kupiec LR (95%)
scalar T1_95_CRM    = @sum(HIT95_CRM)
scalar T0_95_CRM    = T_OBS - T1_95_CRM
scalar P_95_CRM     = T1_95_CRM / T_OBS
scalar LR_KUP95_CRM = -2*(T1_95_CRM*@log(0.05) + T0_95_CRM*@log(0.95) _
                        - T1_95_CRM*@log(P_95_CRM + 1e-10) _
                        - T0_95_CRM*@log(1 - P_95_CRM + 1e-10))
scalar PVAL_KUP95_CRM = 1 - @cchisq(LR_KUP95_CRM, 1)

' GOOGL -- Kupiec LR (95%)
scalar T1_95_GOOGL    = @sum(HIT95_GOOGL)
scalar T0_95_GOOGL    = T_OBS - T1_95_GOOGL
scalar P_95_GOOGL     = T1_95_GOOGL / T_OBS
scalar LR_KUP95_GOOGL = -2*(T1_95_GOOGL*@log(0.05) + T0_95_GOOGL*@log(0.95) _
                          - T1_95_GOOGL*@log(P_95_GOOGL + 1e-10) _
                          - T0_95_GOOGL*@log(1 - P_95_GOOGL + 1e-10))
scalar PVAL_KUP95_GOOGL = 1 - @cchisq(LR_KUP95_GOOGL, 1)

' META -- Kupiec LR (95%)
scalar T1_95_META    = @sum(HIT95_META)
scalar T0_95_META    = T_OBS - T1_95_META
scalar P_95_META     = T1_95_META / T_OBS
scalar LR_KUP95_META = -2*(T1_95_META*@log(0.05) + T0_95_META*@log(0.95) _
                         - T1_95_META*@log(P_95_META + 1e-10) _
                         - T0_95_META*@log(1 - P_95_META + 1e-10))
scalar PVAL_KUP95_META = 1 - @cchisq(LR_KUP95_META, 1)

' MSFT -- Kupiec LR (95%)
scalar T1_95_MSFT    = @sum(HIT95_MSFT)
scalar T0_95_MSFT    = T_OBS - T1_95_MSFT
scalar P_95_MSFT     = T1_95_MSFT / T_OBS
scalar LR_KUP95_MSFT = -2*(T1_95_MSFT*@log(0.05) + T0_95_MSFT*@log(0.95) _
                         - T1_95_MSFT*@log(P_95_MSFT + 1e-10) _
                         - T0_95_MSFT*@log(1 - P_95_MSFT + 1e-10))
scalar PVAL_KUP95_MSFT = 1 - @cchisq(LR_KUP95_MSFT, 1)

' NVDA -- Kupiec LR (95%)
scalar T1_95_NVDA    = @sum(HIT95_NVDA)
scalar T0_95_NVDA    = T_OBS - T1_95_NVDA
scalar P_95_NVDA     = T1_95_NVDA / T_OBS
scalar LR_KUP95_NVDA = -2*(T1_95_NVDA*@log(0.05) + T0_95_NVDA*@log(0.95) _
                         - T1_95_NVDA*@log(P_95_NVDA + 1e-10) _
                         - T0_95_NVDA*@log(1 - P_95_NVDA + 1e-10))
scalar PVAL_KUP95_NVDA = 1 - @cchisq(LR_KUP95_NVDA, 1)

' TSM -- Kupiec LR (95%)
scalar T1_95_TSM    = @sum(HIT95_TSM)
scalar T0_95_TSM    = T_OBS - T1_95_TSM
scalar P_95_TSM     = T1_95_TSM / T_OBS
scalar LR_KUP95_TSM = -2*(T1_95_TSM*@log(0.05) + T0_95_TSM*@log(0.95) _
                        - T1_95_TSM*@log(P_95_TSM + 1e-10) _
                        - T0_95_TSM*@log(1 - P_95_TSM + 1e-10))
scalar PVAL_KUP95_TSM = 1 - @cchisq(LR_KUP95_TSM, 1)

'------------------------------------------------------------
' MATRIZ DE RESULTADOS DEL BACKTESTING (6x8)
' Filas: CRM, GOOGL, META, MSFT, NVDA, TSM
' Columnas:
'   C1 = Tasa de cobertura observada VaR99
'   C2 = LR Kupiec VaR99
'   C3 = p-valor Kupiec VaR99
'   C4 = Tasa de cobertura observada VaR95
'   C5 = LR Kupiec VaR95
'   C6 = p-valor Kupiec VaR95
'   C7 = Nro. violaciones VaR99
'   C8 = Nro. violaciones VaR95
' Criterio de decision: p-valor > 0.05 -> no rechazar H_0
'   -> el modelo de VaR es estadisticamente adecuado.
'------------------------------------------------------------

delete(noerr) BACKTESTING
matrix(6,8) BACKTESTING

BACKTESTING(1,1) = COVER99_CRM
BACKTESTING(1,2) = LR_KUP99_CRM
BACKTESTING(1,3) = PVAL_KUP99_CRM
BACKTESTING(1,4) = COVER95_CRM
BACKTESTING(1,5) = LR_KUP95_CRM
BACKTESTING(1,6) = PVAL_KUP95_CRM
BACKTESTING(1,7) = T1_99_CRM
BACKTESTING(1,8) = T1_95_CRM

BACKTESTING(2,1) = COVER99_GOOGL
BACKTESTING(2,2) = LR_KUP99_GOOGL
BACKTESTING(2,3) = PVAL_KUP99_GOOGL
BACKTESTING(2,4) = COVER95_GOOGL
BACKTESTING(2,5) = LR_KUP95_GOOGL
BACKTESTING(2,6) = PVAL_KUP95_GOOGL
BACKTESTING(2,7) = T1_99_GOOGL
BACKTESTING(2,8) = T1_95_GOOGL

BACKTESTING(3,1) = COVER99_META
BACKTESTING(3,2) = LR_KUP99_META
BACKTESTING(3,3) = PVAL_KUP99_META
BACKTESTING(3,4) = COVER95_META
BACKTESTING(3,5) = LR_KUP95_META
BACKTESTING(3,6) = PVAL_KUP95_META
BACKTESTING(3,7) = T1_99_META
BACKTESTING(3,8) = T1_95_META

BACKTESTING(4,1) = COVER99_MSFT
BACKTESTING(4,2) = LR_KUP99_MSFT
BACKTESTING(4,3) = PVAL_KUP99_MSFT
BACKTESTING(4,4) = COVER95_MSFT
BACKTESTING(4,5) = LR_KUP95_MSFT
BACKTESTING(4,6) = PVAL_KUP95_MSFT
BACKTESTING(4,7) = T1_99_MSFT
BACKTESTING(4,8) = T1_95_MSFT

BACKTESTING(5,1) = COVER99_NVDA
BACKTESTING(5,2) = LR_KUP99_NVDA
BACKTESTING(5,3) = PVAL_KUP99_NVDA
BACKTESTING(5,4) = COVER95_NVDA
BACKTESTING(5,5) = LR_KUP95_NVDA
BACKTESTING(5,6) = PVAL_KUP95_NVDA
BACKTESTING(5,7) = T1_99_NVDA
BACKTESTING(5,8) = T1_95_NVDA

BACKTESTING(6,1) = COVER99_TSM
BACKTESTING(6,2) = LR_KUP99_TSM
BACKTESTING(6,3) = PVAL_KUP99_TSM
BACKTESTING(6,4) = COVER95_TSM
BACKTESTING(6,5) = LR_KUP95_TSM
BACKTESTING(6,6) = PVAL_KUP95_TSM
BACKTESTING(6,7) = T1_99_TSM
BACKTESTING(6,8) = T1_95_TSM

show BACKTESTING



'=========================================================
' BLOQUE 11: SHARPE RATIO CONDICIONAL
'---------------------------------------------------------
' El Sharpe Ratio condicional de periodo t se define como:
'
'   SR_t = (r_t - RF_t) / sigma_t
'
' donde:
'   r_t   = retorno logaritmico semanal del activo
'   RF_t  = tasa libre de riesgo semanal (Bloque 6)
'   sigma_t   = volatilidad condicional semanal (Bloque 5)
'
' A diferencia del Sharpe Ratio clasico (Sharpe, 1966),
' que usa sigma constante (desviacion historica), aqui sigma_t
' es dinamica (GARCH), capturando los cambios en riesgo
' a lo largo del tiempo. Este enfoque es consistente con
' la literatura de media-varianza condicional
' (Hansen & Lunde, 2005).
'
' Anualizacion del Sharpe Ratio:
'   SR_anual = E[SR_t] * sqrt52
'
' La multiplicacion por sqrtT es la escala estandar para
' convertir un ratio semanal a anual, analoga a la
' formula de la raiz del tiempo para volatilidad.
'
' Interpretacion:
'   SR > 1    -> rendimiento ajustado al riesgo excelente
'   SR in (0,1) -> rendimiento positivo pero moderado
'   SR < 0    -> rendimiento inferior a la tasa libre de
'               riesgo (destruccion de valor ajustada)
'
' Referencias:
'   Sharpe, W.F. (1966). "Mutual Fund Performance."
'     Journal of Business, 39(S1), 119-138.
'   Hansen, P.R. & Lunde, A. (2005). "A Forecast
'     Comparison of Volatility Models." Journal of
'     Applied Econometrics, 20(7), 873-889.
'=========================================================

series SR_CRM   = (r_crm   - RF_DEC) / VOLATILIDAD_CONDICIONAL_CRM
series SR_GOOGL = (r_googl - RF_DEC) / VOLATILIDAD_CONDICIONAL_GOOGL
series SR_META  = (r_meta  - RF_DEC) / VOLATILIDAD_CONDICIONAL_META
series SR_MSFT  = (r_msft  - RF_DEC) / VOLATILIDAD_CONDICIONAL_MSFT
series SR_NVDA  = (r_nvda  - RF_DEC) / VOLATILIDAD_CONDICIONAL_NVDA
series SR_TSM   = (r_tsm   - RF_DEC) / VOLATILIDAD_CONDICIONAL_TSM
' CORRECCION v2: se usa VOLATILIDAD_CONDICIONAL (escala semanal) en lugar de
' SIGMA (volatilidad anualizada). El numerador r_t - RF_DEC tambien esta en
' escala semanal; dividir ambos en la misma escala es correcto. La
' anualizacion se aplica unicamente al ratio promedio: E[SR_t] x sqrt52.

scalar SR_CRM_ANUAL   = @mean(SR_CRM)   * @sqrt(52)
scalar SR_GOOGL_ANUAL = @mean(SR_GOOGL) * @sqrt(52)
scalar SR_META_ANUAL  = @mean(SR_META)  * @sqrt(52)
scalar SR_MSFT_ANUAL  = @mean(SR_MSFT)  * @sqrt(52)
scalar SR_NVDA_ANUAL  = @mean(SR_NVDA)  * @sqrt(52)
scalar SR_TSM_ANUAL   = @mean(SR_TSM)   * @sqrt(52)



'=========================================================
' BLOQUE 12: RESUMENES DE VOLATILIDAD ANUALIZADA
'---------------------------------------------------------
' Se calcula la media temporal de la volatilidad
' ANUALIZADA (SIGMA = VOLATILIDAD_CONDICIONAL x sqrt52)
' como indicador del nivel promedio de riesgo de cada
' activo durante toda la muestra. Los valores resultantes
' son comparables con volatilidades anualizadas de
' referencia (e.g., indices de mercado, benchmarks).
' NOTA: SIGMA ya esta en escala anual (Bloque 5);
' SIGMA_*_PROM no requiere ningun factor adicional.
'=========================================================

scalar SIGMA_CRM_PROM   = @mean(SIGMA_CRM)
scalar SIGMA_GOOGL_PROM = @mean(SIGMA_GOOGL)
scalar SIGMA_META_PROM  = @mean(SIGMA_META)
scalar SIGMA_MSFT_PROM  = @mean(SIGMA_MSFT)
scalar SIGMA_NVDA_PROM  = @mean(SIGMA_NVDA)
scalar SIGMA_TSM_PROM   = @mean(SIGMA_TSM)



'=========================================================
' BLOQUE 13: MATRIZ FINAL DE INDICADORES DE RIESGO
'---------------------------------------------------------
' Dimension: 6 activos x 4 indicadores
'
' Columna 1 (C1): Volatilidad anualizada promedio
'   = media de sigma_t * sqrt52 sobre la muestra.
'   Mide el riesgo total promedio de cada activo.
'   Unidades: decimal (e.g., 0.35 = 35% anual).
'
' Columna 2 (C2): VaR 95% promedio semanal
'   = perdida maxima semanal con 95% de confianza,
'     promediada sobre la muestra.
'   Unidades: decimal (e.g., 0.02 = 2% semanal).
'
' Columna 3 (C3): VaR 99% promedio semanal
'   = perdida maxima semanal con 99% de confianza.
'   Siempre mayor que el VaR 95% por construccion.
'
' Columna 4 (C4): Sharpe Ratio anualizado condicional
'   = rendimiento por unidad de riesgo anualizado.
'   Comparable entre activos con diferente escala de
'   retorno y volatilidad.
'
' NOTA: Para analisis de gestion de riesgo, complementar
' con la matriz BACKTESTING (Bloque 10) que valida la
' precision estadistica del VaR calculado.
'=========================================================

delete(noerr) INDICADORES
matrix(6,4) INDICADORES

' CRM
INDICADORES(1,1) = SIGMA_CRM_PROM
INDICADORES(1,2) = VAR95_CRM_PROM
INDICADORES(1,3) = VAR99_CRM_PROM
INDICADORES(1,4) = SR_CRM_ANUAL

' GOOGL
INDICADORES(2,1) = SIGMA_GOOGL_PROM
INDICADORES(2,2) = VAR95_GOOGL_PROM
INDICADORES(2,3) = VAR99_GOOGL_PROM
INDICADORES(2,4) = SR_GOOGL_ANUAL

' META
INDICADORES(3,1) = SIGMA_META_PROM
INDICADORES(3,2) = VAR95_META_PROM
INDICADORES(3,3) = VAR99_META_PROM
INDICADORES(3,4) = SR_META_ANUAL

' MSFT
INDICADORES(4,1) = SIGMA_MSFT_PROM
INDICADORES(4,2) = VAR95_MSFT_PROM
INDICADORES(4,3) = VAR99_MSFT_PROM
INDICADORES(4,4) = SR_MSFT_ANUAL

' NVDA
INDICADORES(5,1) = SIGMA_NVDA_PROM
INDICADORES(5,2) = VAR95_NVDA_PROM
INDICADORES(5,3) = VAR99_NVDA_PROM
INDICADORES(5,4) = SR_NVDA_ANUAL

' TSM
INDICADORES(6,1) = SIGMA_TSM_PROM
INDICADORES(6,2) = VAR95_TSM_PROM
INDICADORES(6,3) = VAR99_TSM_PROM
INDICADORES(6,4) = SR_TSM_ANUAL

show INDICADORES



'=========================================================
' BLOQUE 14: VISUALIZACION DE SERIES DINAMICAS
'---------------------------------------------------------
' Se grafican las volatilidades y VaR dinamicos para
' inspeccion visual de patrones de volatilidad
' (clustering, shocks, asimetria).
'=========================================================

' --- Grupo de volatilidades condicionales semanales ---
delete(noerr) grp_vol
group grp_vol VOLATILIDAD_CONDICIONAL_CRM VOLATILIDAD_CONDICIONAL_GOOGL _
              VOLATILIDAD_CONDICIONAL_META VOLATILIDAD_CONDICIONAL_MSFT _
              VOLATILIDAD_CONDICIONAL_NVDA VOLATILIDAD_CONDICIONAL_TSM
freeze(graf_vol) grp_vol.line
graf_vol.addtext(t) "Volatilidad Condicional Semanal GARCH-t"
show graf_vol

' --- VaR 99% dinamico para todos los activos ---
delete(noerr) grp_var99
group grp_var99 VAR99_CRM VAR99_GOOGL VAR99_META _
                VAR99_MSFT VAR99_NVDA VAR99_TSM
freeze(graf_var99) grp_var99.line
graf_var99.addtext(t) "VaR 99% Dinamico Semanal (perdida positiva)"
show graf_var99


@uiprompt("Proceso completado. Matrices INDICADORES y BACKTESTING generadas." _
          + @chr(10) + "Activos: CRM, GOOGL, META, MSFT, NVDA, TSM." _
          + @chr(10) + "Verificar p-valores Kupiec en matriz BACKTESTING.")

'=========================================================
' FIN DEL PROGRAMA
'=========================================================


