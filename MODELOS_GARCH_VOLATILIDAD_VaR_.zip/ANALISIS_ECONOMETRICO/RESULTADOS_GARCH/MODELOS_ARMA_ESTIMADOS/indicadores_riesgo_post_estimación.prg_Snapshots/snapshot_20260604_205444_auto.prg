' =============================================================================
' PROGRAMA:  Indicadores de Riesgo y Retorno — Panel de Empresas de IA
' OBJETIVO:  A partir de las volatilidades condicionales estimadas por los
'            modelos GARCH óptimos de cada empresa, calcular:
'            (1) Volatilidad anualizada
'            (2) Value at Risk (VaR) al 95% y 99% — semanal
'            (3) Sharpe Ratio condicional anualizado
'            y consolidar los resultados en una matriz de indicadores.
'
' SERIES REQUERIDAS EN EL WORKFILE:
'            Precios en niveles : NVDA, MSFT, GOOGL, META, TSM, CRM
'            Benchmarks         : SP500, NASDAQ100
'            Varianzas cond.    : VOLATILIDAD_CONDICIONAL_GOOGL
'                                 VOLATILIDAD_CONDICIONAL_META
'                                 VOLATILIDAD_CONDICIONAL_MSFT
'                                 VOLATILIDAD_CONDICIONAL_NVDA
'            Tasa libre riesgo  : RF (expresada en % semanal efectivo)
'
' MODELOS GARCH ÓPTIMOS SELECCIONADOS (criterio BIC):
'            GOOGL : AR(1) - GARCH(1,1) | DOF t-Student = 19.02
'            META  : AR(1) - GARCH(1,1) | DOF t-Student =  6.36
'            MSFT  : MA(1) - GARCH(1,3) | DOF t-Student = 13.60
'            NVDA  : AR(1) - GARCH(1,1) | DOF t-Student = 14.37
'
' NOTA METODOLÓGICA:
'            Las volatilidades condicionales exportadas desde EViews
'            corresponden a la VARIANZA condicional (sigma^2). Se aplica
'            la raíz cuadrada para obtener la desviación estándar (sigma).
'            La anualización sigue la regla de la raíz cuadrada del tiempo:
'            sigma_anual = sigma_semanal * sqrt(52)
'            Respaldo: Jorion (2007), Bollerslev et al. (1994), Basilea II/III.
'
' AUTOR:     Joan Valderrama Inoñan
' FECHA:     Junio 2026
' VERSION:   1.0
' =============================================================================

' ============================================================
' SECCIÓN 1: Retornos logarítmicos de las seis empresas
' ============================================================
series r_crm   = log(crm   / crm(-1))
series r_googl = log(googl / googl(-1))
series r_meta  = log(meta  / meta(-1))
series r_msft  = log(msft  / msft(-1))
series r_nvda  = log(nvda  / nvda(-1))
series r_tsm   = log(tsm   / tsm(-1))

equation eq_crm.ls CRM C
equation eq_googl.ls GOOGL C
equation eq_meta.ls META C
equation eq_msft.ls MSFT C
equation eq_nvda.ls NVDA C
equation eq_tsm.ls TSM C 

eq_crm.makeresids resid_crm
eq_googl.makeresids resid_googl
eq_meta.makeresids resid_meta
eq_msft.makeresids resid_msft
eq_nvda.makeresids resid_nvda
eq_tsm.makeresids resid_tsm


freeze(arch_crm)   eq_crm.archtest(1)


_crm.arch(1)
eq_googl.arch(1)
eq_meta.arch(1)
eq_msft.arch(1)
eq_nvda.arch(1)
eq_tsm.arch(1)








' ============================================================
' SECCIÓN 2: Conversión de varianza condicional a volatilidad
'            (raíz cuadrada de la varianza condicional exportada)
' ============================================================
series SIGMA_GOOGL = sqr(volatilidad_condicional_googl)
series SIGMA_META  = sqr(volatilidad_condicional_meta)
series SIGMA_MSFT  = sqr(volatilidad_condicional_msft)
series SIGMA_NVDA  = sqr(volatilidad_condicional_nvda)


' ============================================================
' SECCIÓN 3: Volatilidad anualizada
'            sigma_anual = sigma_semanal * sqrt(52)
' ============================================================
series SIGMA_GOOGL_ANUAL = SIGMA_GOOGL * sqr(52)
series SIGMA_META_ANUAL  = SIGMA_META  * sqr(52)
series SIGMA_MSFT_ANUAL  = SIGMA_MSFT  * sqr(52)
series SIGMA_NVDA_ANUAL  = SIGMA_NVDA  * sqr(52)


' ============================================================
' SECCIÓN 4: Corrección de escala de RF
'            RF está expresada en porcentaje (ej. 1.82 = 1.82%)
'            Los retornos r_i están en decimales (ej. 0.015 = 1.5%)
'            -> Se divide RF entre 100 para unificar escala
' ============================================================
series RF_DEC = rf / 100/52


' ============================================================
' SECCIÓN 5: Restricción de muestra a observaciones comunes
'            (excluye NA al inicio por retornos y GARCH)
' ============================================================
smpl if SIGMA_GOOGL <> na and SIGMA_META  <> na and _
        SIGMA_MSFT  <> na and SIGMA_NVDA  <> na and _
        r_googl     <> na and r_meta      <> na and _
        r_msft      <> na and r_nvda      <> na and _
        RF_DEC      <> na


' ============================================================
' SECCIÓN 6: Value at Risk (VaR) dinámico semanal
'            Distribución t-Student con DOF por modelo óptimo
'            VaR_t = q_{alpha, DOF} * sigma_t
'            Resultado: pérdida máxima semanal (valor negativo)
' ============================================================

' --- VaR al 99% ---
series VAR99_GOOGL = @qtdist(0.01, 19.02) * SIGMA_GOOGL
series VAR99_META  = @qtdist(0.01,  6.36) * SIGMA_META
series VAR99_MSFT  = @qtdist(0.01, 13.60) * SIGMA_MSFT
series VAR99_NVDA  = @qtdist(0.01, 14.37) * SIGMA_NVDA

' --- VaR al 95% ---
series VAR95_GOOGL = @qtdist(0.05, 19.02) * SIGMA_GOOGL
series VAR95_META  = @qtdist(0.05,  6.36) * SIGMA_META
series VAR95_MSFT  = @qtdist(0.05, 13.60) * SIGMA_MSFT
series VAR95_NVDA  = @qtdist(0.05, 14.37) * SIGMA_NVDA

' --- Escalares resumen: VaR promedio del período ---
scalar VAR99_GOOGL_PROM = @mean(VAR99_GOOGL)
scalar VAR99_META_PROM  = @mean(VAR99_META)
scalar VAR99_MSFT_PROM  = @mean(VAR99_MSFT)
scalar VAR99_NVDA_PROM  = @mean(VAR99_NVDA)

scalar VAR95_GOOGL_PROM = @mean(VAR95_GOOGL)
scalar VAR95_META_PROM  = @mean(VAR95_META)
scalar VAR95_MSFT_PROM  = @mean(VAR95_MSFT)
scalar VAR95_NVDA_PROM  = @mean(VAR95_NVDA)


' ============================================================
' SECCIÓN 7: Sharpe Ratio condicional anualizado
'            SR_t = (r_t - RF_DEC_t) / sigma_t      [semanal]
'            SR_anual = mean(SR_t) * sqrt(52)
'            Respaldo: Lo (2002), Financial Analysts Journal
' ============================================================
series SR_GOOGL = (r_googl - RF_DEC) / SIGMA_GOOGL
series SR_META  = (r_meta  - RF_DEC) / SIGMA_META
series SR_MSFT  = (r_msft  - RF_DEC) / SIGMA_MSFT
series SR_NVDA  = (r_nvda  - RF_DEC) / SIGMA_NVDA

scalar SR_GOOGL_ANUAL = @mean(SR_GOOGL) * sqr(52)
scalar SR_META_ANUAL  = @mean(SR_META)  * sqr(52)
scalar SR_MSFT_ANUAL  = @mean(SR_MSFT)  * sqr(52)
scalar SR_NVDA_ANUAL  = @mean(SR_NVDA)  * sqr(52)


' ============================================================
' SECCIÓN 8: Volatilidad media anualizada (escalares resumen)
' ============================================================
scalar SIGMA_GOOGL_PROM = @mean(SIGMA_GOOGL_ANUAL)
scalar SIGMA_META_PROM  = @mean(SIGMA_META_ANUAL)
scalar SIGMA_MSFT_PROM  = @mean(SIGMA_MSFT_ANUAL)
scalar SIGMA_NVDA_PROM  = @mean(SIGMA_NVDA_ANUAL)


' ============================================================
' SECCIÓN 9: Restaurar muestra completa
' ============================================================
smpl @all


' ============================================================
' SECCIÓN 10: Matriz de indicadores financieros consolidada
'
'  Estructura:
'             C1 = Volatilidad anualizada promedio
'             C2 = VaR 95% promedio (semanal)
'             C3 = VaR 99% promedio (semanal)
'             C4 = Sharpe Ratio anualizado
'
'  Filas:  R1=GOOGL | R2=META | R3=MSFT | R4=NVDA
' ============================================================
if @isobject("INDICADORES") then
   delete INDICADORES
endif
matrix(4,4) INDICADORES

' --- GOOGL ---
INDICADORES(1,1) = SIGMA_GOOGL_PROM
INDICADORES(1,2) = VAR95_GOOGL_PROM
INDICADORES(1,3) = VAR99_GOOGL_PROM
INDICADORES(1,4) = SR_GOOGL_ANUAL

' --- META ---
INDICADORES(2,1) = SIGMA_META_PROM
INDICADORES(2,2) = VAR95_META_PROM
INDICADORES(2,3) = VAR99_META_PROM
INDICADORES(2,4) = SR_META_ANUAL

' --- MSFT ---
INDICADORES(3,1) = SIGMA_MSFT_PROM
INDICADORES(3,2) = VAR95_MSFT_PROM
INDICADORES(3,3) = VAR99_MSFT_PROM
INDICADORES(3,4) = SR_MSFT_ANUAL

' --- NVDA ---
INDICADORES(4,1) = SIGMA_NVDA_PROM
INDICADORES(4,2) = VAR95_NVDA_PROM
INDICADORES(4,3) = VAR99_NVDA_PROM
INDICADORES(4,4) = SR_NVDA_ANUAL

show INDICADORES

@uiprompt("Proceso completado. Matriz INDICADORES generada con volatilidad, VaR95, VaR99 y Sharpe Ratio para GOOGL, META, MSFT y NVDA.")

' ============================================================
' FIN DEL PROGRAMA
' ============================================================


