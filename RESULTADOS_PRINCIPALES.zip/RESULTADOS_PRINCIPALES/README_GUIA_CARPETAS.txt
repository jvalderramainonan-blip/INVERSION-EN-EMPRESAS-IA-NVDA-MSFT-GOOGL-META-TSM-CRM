================================================================================
  RESULTADOS_PRINCIPALES — GUIA DE EXPLORACION DEL REPOSITORIO
================================================================================
  Proyecto  : Evaluacion de Inversion en Empresas de Inteligencia Artificial
  Autor     : Joan Valderrama Inonan
  Contexto  : Caso practico — Proceso de seleccion Macroconsult
  Fecha     : Junio 2026
================================================================================


DESCRIPCION GENERAL
-------------------
Este repositorio contiene todos los insumos y resultados del analisis
cuantitativo desarrollado para evaluar la conveniencia de invertir en
acciones de empresas vinculadas a la Inteligencia Artificial.

El entregable final es la presentacion en PowerPoint de maximo 6 diapositivas.
Los demas archivos documentan el sustento metodologico y econometrico detras
de cada afirmacion de la presentacion.

El analisis se apoya en tres pilares:

  1. Analisis de cartera (optimizacion de Markowitz con datos semanales)
  2. Modelo GARCH + metricas de riesgo (volatilidad condicional, VaR dinamico
     y Sharpe Ratio — software: EViews)
  3. Modelo Markov Switching (estados economicos a partir del ciclo del PIB
     y credito no financiero — software: MATLAB)


================================================================================
  ESTRUCTURA DE CARPETAS
================================================================================

  RESULTADOS_PRINCIPALES/
  |
  |-- CASO_PRACTICO_JOAN_VALDERRAMA_INONAN.pptx   <-- ENTREGABLE FINAL
  |
  |-- ANALISIS_CARTERA/
  |     |-- DATOS_SEMANALES_ACCIONES_IA.xlsx
  |     |-- DATOS_DAMODARAN_EQUITY_RISK_PREMIUM.xlsx
  |     +-- PORTAFOLIO_MARKOWITZ.xlsx
  |
  +-- ANALISIS_ECONOMETRICO/
        |
        |-- MODELO_GARCH_METRICAS_RIESGO_VaR/
        |     +-- MODELOS_ARMA_ESTIMADOS/
        |           |-- datos_cargados.wf1
        |           |-- codigos_series_creadas.prg
        |           |-- program_arma_panel_ia_v3_final.evsettings
        |           |-- program_arma_panel_ia_v4_parsimonioso.evsettings
        |           |-- garch_var_sharpe_final.prg
        |           |-- garch_var_sharpe_final.~rg          (respaldo automatico)
        |           |-- estados_economia.evsettings
        |           +-- indicadores_riesgo_post_estimacion.evsettings
        |
        +-- MODELO_MARKOV_SWITCHING_ESTADOS_ECONOMIA/
              +-- ms_ctsnf_pbi/
                    |-- main_MS_cycle.m               <-- Script principal PIB
                    |-- main_MS_cycle_CTSNF.m         <-- Script principal credito
                    |-- README.md                     (instrucciones tecnicas)
                    |-- README_CTSNF.md
                    |-- data/                         (series GDPC1 y CTSNF)
                    |-- functions/                    (funciones MATLAB modulares)
                    |-- output_pbi/                   (figuras generadas - PIB)
                    |-- output_ctsnf/                 (figuras generadas - credito)
                    |-- latex_pbi/                    (reporte LaTeX - PIB)
                    +-- latex_ctsnf/                  (reporte LaTeX - credito)


================================================================================
  ENTREGABLE FINAL
================================================================================

  Archivo: CASO_PRACTICO_JOAN_VALDERRAMA_INONAN.pptx

  Presentacion de hasta 6 diapositivas (incluida la de titulo) que sustenta
  la recomendacion de inversion en acciones de empresas de IA para un
  inversionista externo. Cada diapositiva se respalda con los analisis
  cuantitativos descritos en las secciones siguientes.


================================================================================
  ANALISIS_CARTERA
================================================================================

  Herramienta : Microsoft Excel
  Proposito   : Construir y optimizar un portafolio de acciones de IA bajo
                el marco de Media-Varianza de Markowitz.
  Activos     : NVDA, MSFT, GOOGL, META, TSM, CRM

  -----------------------------------------------------------------------
  DATOS_SEMANALES_ACCIONES_IA.xlsx
  -----------------------------------------------------------------------
  Contiene los precios semanales de cierre de los seis activos tecnologicos.
  Es la fuente de datos primaria para calcular retornos logaritmicos,
  covarianzas y metricas de portafolio.

  -----------------------------------------------------------------------
  DATOS_DAMODARAN_EQUITY_RISK_PREMIUM.xlsx
  -----------------------------------------------------------------------
  Contiene el Equity Risk Premium (ERP) por pais y sector estimado por
  Aswath Damodaran (NYU Stern). Descargado desde:
    https://pages.stern.nyu.edu/~adamodar/
  Se usa como insumo para la tasa de descuento y la comparacion de
  rendimientos ajustados por riesgo.

  -----------------------------------------------------------------------
  PORTAFOLIO_MARKOWITZ.xlsx
  -----------------------------------------------------------------------
  Contiene los resultados de la optimizacion: frontera eficiente,
  portafolio de minima varianza, portafolio de maximo Sharpe Ratio,
  pesos optimos y metricas de riesgo-retorno consolidadas.


================================================================================
  ANALISIS_ECONOMETRICO / MODELO_GARCH_METRICAS_RIESGO_VaR
================================================================================

  Herramienta    : EViews (version con soporte para modelos GARCH-t)
  Carpeta trabajo: MODELOS_ARMA_ESTIMADOS/
  Proposito      : Estimar la volatilidad condicional de cada accion,
                   calcular el VaR dinamico bajo distribucion t-Student
                   y el Sharpe Ratio condicional anualizado.

  FLUJO DE TRABAJO (orden de ejecucion en EViews)
  ------------------------------------------------

  PASO 1 — Cargar datos
    Archivo : datos_cargados.wf1
    Workfile de EViews con las series de precios semanales de NVDA, MSFT,
    GOOGL, META, TSM y CRM, mas los benchmarks S&P 500 y NASDAQ 100.
    Abrir este archivo para acceder al entorno de trabajo.

  PASO 2 — Crear retornos y series derivadas
    Archivo : codigos_series_creadas.prg
    Calcula los retornos logaritmicos continuos r_t = ln(P_t / P_{t-1})
    para cada activo. Tambien genera la volatilidad anualizada y las
    metricas de VaR y Sharpe usando los parametros GARCH estimados.

  PASO 3 — Estimar ecuaciones de media ARMA
    Archivos: program_arma_panel_ia_v3_final.evsettings
              program_arma_panel_ia_v4_parsimonioso.evsettings
    Configuraciones de los modelos de ecuacion de media para cada activo.
    La especificacion parsimoniosa (v4) selecciona el ARMA mas adecuado
    para que los residuos queden libres de autocorrelacion antes del
    test ARCH-LM.

  PASO 4 — Estimar GARCH y calcular VaR
    Archivo : garch_var_sharpe_final.prg
    Programa principal. Ejecuta los siguientes bloques en secuencia:
      a) Retornos logaritmicos para los seis activos
      b) Ecuaciones de media estimadas por OLS
      c) Prueba ARCH-LM (Engle, 1982) con rezagos 1 a 4
      d) Seleccion del modelo GARCH(p,q)-t por criterio de Schwarz
      e) VaR dinamico semanal al 95% y 99% con distribucion t-Student
         Grados de libertad por activo: NVDA=14.37, GOOGL=19.02,
                                        META=6.36,  MSFT=13.60
      f) Backtesting: Kupiec (1995) + Christoffersen (1998)
      g) Sharpe Ratio condicional anualizado (escala por raiz de 52)

  PASO 5 — Indicadores de riesgo post-estimacion
    Archivo : indicadores_riesgo_post_estimacion.evsettings
    Tablas y graficos adicionales derivados de los modelos GARCH estimados.

  PASO 6 — Clasificacion por estado de economia
    Archivo : estados_economia.evsettings
    Clasifica los periodos de muestra segun el estado del mercado,
    complementando el analisis del modelo Markov Switching.

  NOTA SOBRE ARCHIVOS AUXILIARES
  --------------------------------
  garch_var_sharpe_final.~rg  -> Copia de respaldo automatica de EViews.
                                  Puede ignorarse durante la exploracion.
  Carpetas *_Snapshots/       -> Instantaneas de versiones anteriores
                                  guardadas automaticamente por EViews.
                                  Utiles para recuperar estados previos.


================================================================================
  ANALISIS_ECONOMETRICO / MODELO_MARKOV_SWITCHING_ESTADOS_ECONOMIA
================================================================================

  Herramienta  : MATLAB R2019b o superior
                 (requiere Statistics and Machine Learning Toolbox)
  Carpeta      : ms_ctsnf_pbi/
  Proposito    : Identificar los regimenes economicos (recesion, neutral,
                 expansion) mediante un modelo Markov Switching MS-MH(3)
                 aplicado al ciclo del PIB real de EE.UU. y al ciclo del
                 credito al sector no financiero.

  EJECUCION
  ---------

  Para el analisis del ciclo del PIB:

    >> cd('ruta/a/ms_ctsnf_pbi')
    >> main_MS_cycle

    El script detecta automaticamente data/gdp_usa.csv (serie GDPC1 de
    FRED: 1947-Q1 a 2026-Q1, 317 observaciones) y ejecuta el pipeline
    completo sin configuracion adicional.

  Para el analisis del credito al sector no financiero (CTSNF):

    >> cd('ruta/a/ms_ctsnf_pbi')
    >> run('data/convert_ctsnf_xlsx.m')   % genera ctsnf_real.csv
    >> main_MS_cycle_CTSNF

  CONTENIDO DE SUBCARPETAS
  -------------------------

  data/
    gdp_usa.csv              Serie GDPC1 (PIB real EE.UU., FRED)
    GDPC1.xlsx               Descarga original de FRED
    ctsnf_real.csv           Serie de credito no financiero (generada)
    COLOQUE_DATOS_AQUI.txt   Instrucciones para actualizar las series
    convert_gdpc1_xlsx.m     Convierte GDPC1.xlsx a gdp_usa.csv
    convert_ctsnf_xlsx.m     Convierte el Excel de CTSNF a CSV

  functions/
    cf_filter_asymmetric.m      Filtro Christiano-Fitzgerald asimetrico
    estimate_markov_switching.m Estimacion MS-MH(K) por algoritmo EM
    identify_regimes.m          Clasificacion de regimenes por media
    plot_gdp_and_cycle.m        Figura 1: PIB y ciclo
    plot_smoothed_probs.m       Figura 2: Probabilidades suavizadas
    plot_transition_matrix.m    Figura 3: Heatmap de transicion
    plot_regime_classification.m Figura 4: Clasificacion historica
    load_gdp_csv.m              Carga de datos desde CSV
    generate_latex_report.m     Generador del reporte tecnico en LaTeX
    compile_latex.m             Compilador pdflatex -> PDF
    run_ms_pipeline.m           Pipeline integrado modular

  output_pbi/ y output_ctsnf/
    fig1_gdp_cycle.pdf           PIB y ciclo CF
    fig2_smoothed_probs.pdf      Probabilidades suavizadas por regimen
    fig3_transition_matrix.pdf   Heatmap de la matriz de transicion
    fig4_regime_classification.pdf Clasificacion historica de regimenes

  latex_pbi/ y latex_ctsnf/
    reporte_MS_ciclo.tex         Reporte tecnico completo (auto-generado)
    (Para compilar: ejecutar pdflatex dos veces sobre el .tex)

  PARAMETROS CONFIGURABLES (en main_MS_cycle.m)
  ----------------------------------------------
    states      = 3       Numero de regimenes del modelo MS
    cf_pl       = 6       Periodo minimo del ciclo CF (trimestres)
    cf_pu       = 32      Periodo maximo del ciclo CF (trimestres)
    cf_drift    = true    Filtro CF asimetrico (acomoda I(1) con drift)
    maxiter     = 2000    Iteraciones maximas del algoritmo EM
    tol         = 1e-7    Tolerancia de convergencia
    n_restarts  = 10      Reinicios aleatorios del EM
    seed        = 42      Semilla para reproducibilidad


================================================================================
  SOFTWARE REQUERIDO
================================================================================

  Modulo                        Herramienta        Version minima
  ----------------------------  -----------------  ----------------------
  Analisis de cartera           Microsoft Excel    2016 o superior
  Modelos GARCH / ARMA / VaR    EViews             10 o superior
  Modelo Markov Switching       MATLAB             R2019b + Stat. Toolbox
  Reporte tecnico (opcional)    LaTeX (pdflatex)   TeX Live 2020 / MiKTeX


================================================================================
  REFERENCIAS METODOLOGICAS
================================================================================

  - Campbell, Lo & MacKinlay (1997). The Econometrics of Financial Markets.
    Princeton University Press.

  - Engle, R.F. (1982). Autoregressive Conditional Heteroscedasticity with
    Estimates of the Variance of United Kingdom Inflation.
    Econometrica, 50(4), 987-1007.

  - Hamilton, J.D. (1989). A New Approach to the Economic Analysis of
    Nonstationary Time Series. Econometrica, 57(2), 357-384.

  - Kim, C.J. (1994). Dynamic Linear Models with Markov-Switching.
    Journal of Econometrics, 60, 1-22.

  - Christiano & Fitzgerald (2003). The Band Pass Filter.
    International Economic Review, 44(2), 435-465.

  - McNeil, Frey & Embrechts (2005). Quantitative Risk Management.
    Princeton University Press.

  - Markowitz, H. (1952). Portfolio Selection.
    Journal of Finance, 7(1), 77-91.

  - Kupiec, P. (1995). Techniques for Verifying the Accuracy of Risk
    Measurement Models. Journal of Derivatives, 3(2), 73-84.


================================================================================
  CONTROL DE VERSIONES
================================================================================

  El repositorio esta bajo control Git.
  Para ver el historial de cambios, ejecutar desde la carpeta raiz:

    git log --oneline

================================================================================
  FIN DEL DOCUMENTO
================================================================================
